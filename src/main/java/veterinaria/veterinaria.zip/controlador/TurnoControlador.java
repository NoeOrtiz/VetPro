package veterinaria.controlador;

@Deprecated
public class TurnoControlador extends PeluqueriaControlador {
    // Clase puente por compatibilidad histórica.
}
