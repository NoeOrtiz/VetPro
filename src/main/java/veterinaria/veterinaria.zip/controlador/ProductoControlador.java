
package veterinaria.controlador;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import veterinaria.entidad.Producto;
import veterinaria.persistencia.ProductoDAO;

public class ProductoControlador {
    private ProductoDAO productoDAO = new ProductoDAO();
    
    public boolean crearProducto(Producto producto){
        try {
            return productoDAO.crear(producto);
        } catch (Exception ex) {
            Logger.getLogger(MascotaControlador.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public boolean actualizarProducto(Producto producto){
        try {
            return productoDAO.actualizar(producto);
        } catch (Exception ex) {
            Logger.getLogger(MascotaControlador.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public boolean eliminarProducto(Producto producto){
        try {
            return productoDAO.eliminar(producto);
        } catch (Exception ex) {
            Logger.getLogger(MascotaControlador.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public List<Producto> buscarTodosLosProductos(){
        return productoDAO.buscarTodos();
    }

    public List<Producto> buscarProductosPorEstado(String estadoFiltro){
        return productoDAO.buscarPorEstado(estadoFiltro);
    }
    
    public Producto buscarProductoPorId(Integer idProducto){
        return productoDAO.buscarPorId(idProducto);
    }

    public boolean actualizarStockVentaProducto(Integer idProducto, Integer cantidad) {
        return productoDAO.actualizarStockVenta(idProducto, cantidad);
    }
}
