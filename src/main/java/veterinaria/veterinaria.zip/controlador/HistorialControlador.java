package veterinaria.controlador;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import veterinaria.entidad.HistorialConsumo;
import veterinaria.entidad.Mascota;
import veterinaria.persistencia.HistorialConsumoDAO;
import veterinaria.persistencia.MascotaDAO;

public class HistorialControlador {

   /*private final HistorialConsumoDAO historialDAO = new HistorialConsumoDAO();

    // Método para crear un historial de consumo
    public void crearHistorialConsumo(HistorialConsumo historial) {
        historialDAO.guardarHistorial(historial);
    }

    // Método para obtener el historial de una mascota
    public List<HistorialConsumo> verHistorialPorMascota(Integer idMascota) {
        return historialDAO.obtenerHistorialPorMascota(idMascota);
    }

    // Método para obtener el historial de una mascota por tipo de servicio
    public List<HistorialConsumo> verHistorialPorMascotaYTipo(Integer idMascota, String tipoServicio) {
        return historialDAO.obtenerHistorialPorMascotaYTipo(idMascota, tipoServicio);
    }*/
}
