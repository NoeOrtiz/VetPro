
package veterinaria.controlador;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import veterinaria.entidad.Cliente;
import veterinaria.entidad.Persona;
import veterinaria.persistencia.ClienteDAO;
        
public class ClienteControlador {
    private final ClienteDAO clienteDAO = new ClienteDAO();
    
    public boolean crearPersonaCliente(Persona persona, Cliente cliente) throws Exception{
        validarDatos(cliente);
        return clienteDAO.crear(persona, cliente);
    }
    
    private void validarDatos(Cliente cliente) throws Exception{
        if (cliente.getEmail() == null || cliente.getEmail().isEmpty()) {
            throw new Exception("El email no puede estar vacío.");
        }
    }
    
    public List<Cliente> buscarTodosLosClientes() {
        return clienteDAO.buscarTodos();
    }
    
    public List<Cliente> buscarClientesSinCuentaCorriente() {
        return clienteDAO.buscarClientesSinCuentaCorriente();
    }
   
    public Cliente buscarPorEmail(String cliente){
        return clienteDAO.buscarPorEmail(cliente);
    }
    
    public Cliente buscarPorId(Integer idCliente){
        return clienteDAO.buscarPorId(idCliente);
    }
    
    public Boolean actualizarCliente(Persona persona, Cliente cliente){
        return clienteDAO.actualizar(persona, cliente);
    }
    
    public boolean eliminarCliente(Persona persona, Cliente cliente){
        try {
            return clienteDAO.eliminar(persona, cliente);
        } catch (Exception ex) {
            Logger.getLogger(ClienteControlador.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }      
    }
}
