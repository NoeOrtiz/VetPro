
package veterinaria.controlador;

import java.io.InputStream;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import java.util.Map;
import veterinaria.util.jaspersoft.Conexion;

public class ReporteControlador {
    Conexion cx = new Conexion();    

    public JasperPrint reporteReciboVentas(Map<String, Object> parametro) {
        Connection cn = cx.obtenerConexion();

        try {
            // Asegurar classloader (suele fallar en IDE / ejecución desde NetBeans)
            Thread.currentThread().setContextClassLoader(getClass().getClassLoader());

            // 1) Intentar cargar el .jasper
            InputStream reporteStream = getClass().getResourceAsStream("/reportes/ReporteReciboVenta.jasper");
            if (reporteStream != null) {
                JasperReport jasperReport = (JasperReport) JRLoader.loadObject(reporteStream);
                return JasperFillManager.fillReport(jasperReport, parametro, cn);
            }

            // 2) Fallback: compilar desde .jrxml
            InputStream jrxmlStream = getClass().getResourceAsStream("/reportes/ReporteReciboVenta.jrxml");
            if (jrxmlStream == null) {
                System.out.println("No se encontró ReporteReciboVenta.jasper ni ReporteReciboVenta.jrxml en /reportes");
                return null;
            }

            JasperReport compiled = JasperCompileManager.compileReport(jrxmlStream);
            return JasperFillManager.fillReport(compiled, parametro, cn);
            
        } catch (JRException ex) {
            Logger.getLogger(ReporteControlador.class.getName()).log(Level.SEVERE, "Error al generar el reporte", ex);
        }

        return null;
    }
}
