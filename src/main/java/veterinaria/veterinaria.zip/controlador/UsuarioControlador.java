package veterinaria.controlador;

import veterinaria.entidad.Usuario;
import java.util.List;
import veterinaria.entidad.Persona;
import veterinaria.entidad.Rol;
import veterinaria.persistencia.UsuarioDAO;
import veterinaria.servicio.AutenticacionService;

public class UsuarioControlador {
    private final UsuarioDAO usuarioDAO = new UsuarioDAO();
    private final AutenticacionService autenticacionService = new AutenticacionService();
    
    public boolean registrarUsuario(Persona datosPersona, Usuario datosUsuario, Rol rolUsuario){
        boolean retornar;
        datosUsuario.setRol(rolUsuario);
        return retornar = usuarioDAO.crearUsuario(datosPersona, datosUsuario);
    }
       
    public Usuario obtenerUsuario(int idUsuario) {
        return usuarioDAO.obtenerPorId(idUsuario);
    }

    public List<Usuario> obtenerTodosLosUsuarios() {
        return usuarioDAO.obtenerTodos();
    }

    public Usuario buscarPorUsuario(String nombreUsuario) {
        return usuarioDAO.buscarPorNombreUsuario(nombreUsuario);
    }

    public boolean actualizarUsuario(Persona datosPersona, Usuario datosUsuario, Rol rolUsuario) {
        boolean retornar;
        return retornar = usuarioDAO.actualizarUsuario(datosPersona, datosUsuario, rolUsuario);
    }
    
    public boolean eliminarUsuario(Persona persona, Usuario usuario, Rol rol){
        boolean retornar;
        return retornar = usuarioDAO.eliminar(persona, usuario, rol);
    }
    
    public Boolean iniciarSesionUsuario(String usuario, String contraseña) {
        return autenticacionService.validarLogin(usuario, contraseña);
    }

    public boolean recuperarContrasena(String nombreUsuario, String email, String dni, String nuevaContrasena) {
        return autenticacionService.actualizarContrasenaPorRecuperacion(nombreUsuario, email, dni, nuevaContrasena);
    }

    public String solicitarCodigoRecuperacion(String nombreUsuario, String email, String dni) {
        return autenticacionService.generarCodigoRecuperacion(nombreUsuario, email, dni);
    }

    public boolean restablecerConCodigo(String nombreUsuario, String email, String dni, String codigo, String nuevaContrasena) {
        return autenticacionService.restablecerConCodigo(nombreUsuario, email, dni, codigo, nuevaContrasena);
    }
}
