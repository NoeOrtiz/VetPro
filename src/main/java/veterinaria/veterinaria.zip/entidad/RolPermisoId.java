
package veterinaria.entidad;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.util.Objects;

@Embeddable
public class RolPermisoId implements Serializable {

    @Column(name = "idRol")
    private Integer idRol;

    @Column(name = "idPermiso")
    private Integer idPermiso;

    // Constructor vacío
    public RolPermisoId() {}

    // Constructor con parámetros
    public RolPermisoId(Integer idRol, Integer idPermiso) {
        this.idRol = idRol;
        this.idPermiso = idPermiso;
    }

    // Getters y setters
    public Integer getIdRol() {
        return idRol;
    }

    public void setIdRol(Integer idRol) {
        this.idRol = idRol;
    }

    public Integer getIdPermiso() {
        return idPermiso;
    }

    public void setIdPermiso(Integer idPermiso) {
        this.idPermiso = idPermiso;
    }

    // Método equals para comparar correctamente objetos de esta clase
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RolPermisoId that = (RolPermisoId) o;
        return Objects.equals(idRol, that.idRol) &&
               Objects.equals(idPermiso, that.idPermiso);
    }

    // Método hashCode para utilizar correctamente este objeto en colecciones
    @Override
    public int hashCode() {
        return Objects.hash(idRol, idPermiso);
    }
}