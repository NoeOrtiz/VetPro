package veterinaria.entidad;

/**
 * Archivo reservado.
 *
 * El converter válido para Peluquería ahora es:
 * {@link EstadoPeluqueriaEnumConverter}
 */
