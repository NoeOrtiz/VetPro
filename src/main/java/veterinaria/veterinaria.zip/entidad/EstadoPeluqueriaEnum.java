
package veterinaria.entidad;

public enum EstadoPeluqueriaEnum {

    PENDIENTE(
            "Pendiente",
            true, // activo
            false // histórico
    ),
    CONFIRMADO(
            "Confirmado",
            true,
            false
    ),
    COMPLETADO(
            "Completado",
            false,
            true
    ),
    CANCELADO(
            "Cancelado",
            false,
            true
    ),
    ELIMINADO(
            "Eliminado",
            false,
            true
    );

    private final String label;
    private final boolean activo;
    private final boolean historico;

    EstadoPeluqueriaEnum(String label, boolean activo, boolean historico) {
        this.label = label;
        this.activo = activo;
        this.historico = historico;
    }

    /**
     * Texto visible para UI
     */
    public String getLabel() {
        return label;
    }

    /**
     * Turnos que aún requieren gestión
     */
    public boolean esActivo() {
        return activo;
    }

    /**
     * Turnos cerrados / historial
     */
    public boolean esHistorico() {
        return historico;
    }

    @Override
    public String toString() {
        return label;
    }

    /**
     * Valor persistido en BD (compatibilidad: la BD usa los labels en castellano).
     */
    public String getDbValue() {
        return label;
    }

    /**
     * Convierte un texto (BD/UI) a enum. Soporta null y trim.
     */
    public static EstadoPeluqueriaEnum fromLabel(String value) {
        if (value == null) return null;
        String v = value.trim();
        if (v.isEmpty()) return null;
        for (EstadoPeluqueriaEnum e : values()) {
            if (e.label.equalsIgnoreCase(v)) {
                return e;
            }
        }
        // fallback: por si alguien pasa el name() del enum
        try {
            return EstadoPeluqueriaEnum.valueOf(v.toUpperCase());
        } catch (Exception ignore) {
            return null;
        }
    }
}
