package veterinaria.entidad;

/**
 * Estados posibles de una compra a proveedor.
 *
 * Nota: en BD es VARCHAR(16). Se utiliza STRING para trazabilidad.
 */
public enum CompraProveedorEstado {
    REGISTRADA,
    ANULADA
}
