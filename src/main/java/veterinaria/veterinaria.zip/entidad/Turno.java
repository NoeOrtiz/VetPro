package veterinaria.entidad;

/**
 * Clase puente para mantener compatibilidad con código legado.
 * Reemplazada por {@link Peluqueria}.
 */
@Deprecated
public class Turno extends Peluqueria {
    public Turno() { super(); }
}
