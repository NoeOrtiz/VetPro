package veterinaria.entidad;

/**
 * Archivo reservado.
 *
 * Este archivo existía en un parche anterior para la entidad Peluquería.
 * Se reemplazó por {@link EstadoPeluqueriaEnum} para evitar colisiones con
 * otras clases/enums existentes llamadas EstadoPeluqueriaEnum.
 *
 * Si en tu proyecto ya existe un EstadoPeluqueriaEnum propio, conservá ese archivo
 * y podés borrar este sin impacto.
 */
