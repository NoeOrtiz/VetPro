package veterinaria.entidad.util;

/**
 * Item liviano para combos (JComboBox) de Mascotas.
 * Evita depender de toString() de la entidad y facilita obtener el id.
 */
public class MascotaItem {

    private Integer idMascota;
    private String nombre;

    public MascotaItem(Integer idMascota, String nombre) {
        this.idMascota = idMascota;
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }

    public Integer getIdMascota() {
        return idMascota;
    }

    /**
     * @deprecated Compatibilidad con versiones previas (mal nombrado).
     * Usar {@link #getIdMascota()}.
     */
    @Deprecated
    public Integer getIdCliente() {
        return idMascota;
    }
}
