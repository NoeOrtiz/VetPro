package veterinaria.entidad;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "producto")
public class Producto implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idProducto")
    private Integer idProducto;
    
    @Column(name = "codigo")
    private String codigo;
    
    @Column(name = "nombre")
    private String nombre;

    @Column(name = "rubro")
    private String rubro;
    
    @Column(name = "descripcion")
    private String descripcion;  
    
    @Column(name = "precio_costo")
    private Double precioCosto;

    @Column(name = "iva")
    private String iva = "0.0";    

    @Column(name = "descuento")
    private String descuento = "0";    
    
    @Column(name = "umedida")
    private String umedida;

    @Column(name = "stock")
    private Integer stock;        

    /**
     * Stock mínimo sugerido/propio del producto.
     * Regla sugerida: si stockMinimo == 0 (o null), se usa el stock mínimo por defecto del Rubro.
     */
    @Column(name = "stock_minimo")
    private Integer stockMinimo = 0;
        
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "idProveedor", referencedColumnName = "idProveedor")    
    private Proveedor proveedor;

    @Column(name = "estado")
    private String estado; 
    
    public Producto() {
    }

    public Producto(
        Integer idProducto, 
        String codigo, 
        String nombre, 
        String rubro, 
        String descripcion, 
        Double precioCosto, 
        String iva, 
        String descuento, 
        String umedida, 
        Integer stock, 
        Integer stockMinimo,
        Proveedor proveedor, 
        String estado
    ) {
        this.idProducto = idProducto;
        this.codigo = codigo;
        this.nombre = nombre;
        this.rubro = rubro;
        this.descripcion = descripcion;
        this.precioCosto = precioCosto;
        this.iva = iva;
        this.descuento = descuento;
        this.umedida = umedida;
        this.stock = stock;
        this.stockMinimo = (stockMinimo == null ? 0 : stockMinimo);
        this.proveedor = proveedor;
        this.estado = estado;
    }

    public Integer getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Integer idProducto) {
        this.idProducto = idProducto;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRubro() {
        return rubro;
    }

    public void setRubro(String rubro) {
        this.rubro = rubro;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Double getPrecioCosto() {
        return precioCosto;
    }

    public void setPrecioCosto(Double precioCosto) {
        this.precioCosto = precioCosto;
    }

    /**
     * @deprecated Compatibilidad temporal. Usar getPrecioCosto().
     */
    @Deprecated
    public Double getPrecio() {
        return getPrecioCosto();
    }

    /**
     * @deprecated Compatibilidad temporal. Usar setPrecioCosto().
     */
    @Deprecated
    public void setPrecio(Double precio) {
        setPrecioCosto(precio);
    }

    public String getIva() {
        return iva;
    }

    public void setIva(String iva) {
        this.iva = iva;
    }    
    
    public String getDescuento() {
        return descuento;
    }

    public void setDescuento(String descuento) {
        if(descuento == null){
            this.descuento = "";
        }else{
            this.descuento = descuento;
        }
    }

    public String getUmedida() {
        return umedida;
    }

    public void setUmedida(String umedida) {
        this.umedida = umedida;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public Integer getStockMinimo() {
        return stockMinimo;
    }

    public void setStockMinimo(Integer stockMinimo) {
        this.stockMinimo = (stockMinimo == null ? 0 : stockMinimo);
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

}
