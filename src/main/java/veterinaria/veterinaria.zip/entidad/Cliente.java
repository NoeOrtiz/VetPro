
package veterinaria.entidad;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "cliente")
public class Cliente implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idCliente")
    private Integer idCliente;

    // En una app Swing (sin Open-Session-In-View), acceder a cliente.getPersona()
    // desde la UI suele ocurrir fuera del alcance de un EntityManager abierto.
    // Para evitar LazyInitializationException, cargamos Persona de forma EAGER.
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "idPersona", nullable = false)
    private Persona persona;
    
    @Column(name = "email")
    private String email;

    @Column(name = "razonSocial")
    private String razonSocial;

    @Column(name = "cuit")
    private String cuit;
    
    public Cliente() {}

    public Cliente(Integer idCliente, Persona persona, String email, String razonSocial, String cuit) {
        this.idCliente = idCliente;
        this.persona = persona;
        this.email = email;
        this.razonSocial = razonSocial;
        this.cuit = cuit;
    }

    // Getters y setters
    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public Integer getIdCliente() {
        return idCliente;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }
    
}
