package veterinaria.entidad;

/**
 * Estados de una Orden de Compra.
 * - BORRADOR: en edición, aún no confirmada.
 * - CONFIRMADA: lista para recepcionar (puede venir de "Confirmado" en UI).
 * - CERRADA: recepcionada (total o parcialmente según tu regla de cierre).
 * - ANULADA: baja lógica.
 */
public enum CompraOrdenEstado {
    BORRADOR,
    CONFIRMADA,
    CERRADA,
    ANULADA
}
