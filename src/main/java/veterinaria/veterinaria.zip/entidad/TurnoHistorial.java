package veterinaria.entidad;

/**
 * Clase puente para mantener compatibilidad con código legado.
 * Reemplazada por {@link PeluqueriaHistorial}.
 */
@Deprecated
public class TurnoHistorial extends PeluqueriaHistorial {
    public TurnoHistorial() { super(); }
}
