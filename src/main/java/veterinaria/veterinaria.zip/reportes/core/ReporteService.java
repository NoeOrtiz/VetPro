package veterinaria.reportes.core;

import java.awt.Desktop;
import java.io.File;

/**
 * Facade simple para ser usada desde formularios Swing.
 * Evita que la UI conozca detalles de PDFBox.
 */
public class ReporteService {

    private final ReporteRegistry registry = new ReporteRegistry();

    public File generar(ReporteTipo tipo, ReporteRequest request) throws Exception {
        File pdf = registry.get(tipo).generar(request);

        // Abrir automáticamente el PDF en el visor por defecto
        if (Desktop.isDesktopSupported()) {
            try {
                Desktop.getDesktop().open(pdf);
            } catch (Exception ignored) {
                // si falla abrir, el archivo igual quedó generado
            }
        }

        return pdf;
    }
}
