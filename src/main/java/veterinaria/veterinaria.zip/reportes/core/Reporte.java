package veterinaria.reportes.core;

import java.io.File;

/**
 * Contrato base de cualquier reporte.
 */
public interface Reporte {
    ReporteTipo tipo();
    File generar(ReporteRequest request) throws Exception;
}
