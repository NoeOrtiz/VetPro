package veterinaria.reportes.core;

/**
 * Enum central de tipos de reporte.
 * A medida que migremos formularios, iremos sumando nuevos tipos.
 */
public enum ReporteTipo {
    RECIBO_VENTA,
    COMPRA_RECEPCION,
    CC_COBRO,
    CC_MOVIMIENTOS,
    CC_LISTA_CUENTAS,
    LABORATORIO_INFORME,
    HOSPITALIZACION_REGISTRO,
    HISTORIAL_TURNOS,
    HISTORIAL_TURNOS_LISTADO,

    // Usuarios
    USUARIO_REGISTRO,
    USUARIO_LISTADO,

    // Mascotas
    MASCOTA_REGISTRO,
    MASCOTA_LISTADO,

    // Clientes
    CLIENTE_REGISTRO,
    CLIENTE_LISTADO,

    // Productos
    PRODUCTO_REGISTRO,
    PRODUCTO_LISTADO,

    // Stock de Productos
    STOCK_PRODUCTO_REGISTRO,
    STOCK_PRODUCTO_LISTADO,

    // Proveedores
    PROVEEDOR_REGISTRO,
    PROVEEDOR_LISTADO,

    // Visitas
    VISITA_REGISTRO,
    VISITA_LISTADO,

    // Historia Clínica
    HISTORIA_CLINICA,
    HISTORIA_CLINICA_LISTADO,

    // Caja
    CAJA_MOVIMIENTO,
    CAJA_MOVIMIENTOS_LISTADO,

    // Auditoría
    AUDITORIA_EVENTO,
    AUDITORIA_LISTADO
}