package veterinaria.reportes.core;

import java.util.HashMap;
import java.util.Map;

import veterinaria.reportes.impl.AuditoriaEventoPdfReporte;
import veterinaria.reportes.impl.AuditoriaListadoPdfReporte;
import veterinaria.reportes.impl.CajaMovimientoPdfReporte;
import veterinaria.reportes.impl.CajaMovimientosListadoPdfReporte;
import veterinaria.reportes.impl.ClienteListadoPdfReporte;
import veterinaria.reportes.impl.ClienteRegistroPdfReporte;
import veterinaria.reportes.impl.CompraRecepcionPdfReporte;
import veterinaria.reportes.impl.CuentaCorrienteCobroPdfReporte;
import veterinaria.reportes.impl.CuentaCorrienteListadoPdfReporte;
import veterinaria.reportes.impl.CuentaCorrienteMovimientosPdfReporte;
import veterinaria.reportes.impl.HistoriaClinicaListadoPdfReporte;
import veterinaria.reportes.impl.HistoriaClinicaPdfReporte;
import veterinaria.reportes.impl.HistorialTurnosListadoPdfReporte;
import veterinaria.reportes.impl.HistorialTurnosPdfReporte;
import veterinaria.reportes.impl.HospitalizacionRegistroPdfReporte;
import veterinaria.reportes.impl.LaboratorioInformePdfReporte;
import veterinaria.reportes.impl.MascotaListadoPdfReporte;
import veterinaria.reportes.impl.MascotaRegistroPdfReporte;
import veterinaria.reportes.impl.ProductoListadoPdfReporte;
import veterinaria.reportes.impl.ProductoRegistroPdfReporte;
import veterinaria.reportes.impl.StockProductoListadoPdfReporte;
import veterinaria.reportes.impl.StockProductoRegistroPdfReporte;
import veterinaria.reportes.impl.ProveedorListadoPdfReporte;
import veterinaria.reportes.impl.ProveedorRegistroPdfReporte;
import veterinaria.reportes.impl.ReciboVentaPdfReporte;
import veterinaria.reportes.impl.UsuarioListadoPdfReporte;
import veterinaria.reportes.impl.UsuarioRegistroPdfReporte;
import veterinaria.reportes.impl.VisitaListadoPdfReporte;
import veterinaria.reportes.impl.VisitaRegistroPdfReporte;

/**
 * Registro central de reportes.
 *
 * Para agregar un reporte nuevo:
 * 1) Crear la clase que implemente Reporte
 * 2) Registrarla en el constructor.
 */
public class ReporteRegistry {

    private final Map<ReporteTipo, Reporte> map = new HashMap<>();

    public ReporteRegistry() {
        registrar(new ReciboVentaPdfReporte());
        registrar(new CuentaCorrienteCobroPdfReporte());
        registrar(new CuentaCorrienteMovimientosPdfReporte());
        registrar(new CuentaCorrienteListadoPdfReporte());
        registrar(new CompraRecepcionPdfReporte());
        registrar(new LaboratorioInformePdfReporte());
        registrar(new HospitalizacionRegistroPdfReporte());
        registrar(new HistorialTurnosPdfReporte());
        registrar(new HistorialTurnosListadoPdfReporte());

        // Usuarios
        registrar(new UsuarioRegistroPdfReporte());
        registrar(new UsuarioListadoPdfReporte());

        // Mascotas
        registrar(new MascotaRegistroPdfReporte());
        registrar(new MascotaListadoPdfReporte());

        // Clientes
        registrar(new ClienteRegistroPdfReporte());
        registrar(new ClienteListadoPdfReporte());

        // Productos
        registrar(new ProductoRegistroPdfReporte());
        registrar(new ProductoListadoPdfReporte());

        // Stock de Productos
        registrar(new StockProductoRegistroPdfReporte());
        registrar(new StockProductoListadoPdfReporte());

        // Proveedores
        registrar(new ProveedorRegistroPdfReporte());
        registrar(new ProveedorListadoPdfReporte());

        // Visitas
        registrar(new VisitaRegistroPdfReporte());
        registrar(new VisitaListadoPdfReporte());

        // Historia Clínica
        registrar(new HistoriaClinicaPdfReporte());
        registrar(new HistoriaClinicaListadoPdfReporte());

        // Caja
        registrar(new CajaMovimientoPdfReporte());
        registrar(new CajaMovimientosListadoPdfReporte());

        // Auditoría
        registrar(new AuditoriaEventoPdfReporte());
        registrar(new AuditoriaListadoPdfReporte());
    }

    private void registrar(Reporte reporte) {
        map.put(reporte.tipo(), reporte);
    }

    public Reporte get(ReporteTipo tipo) {
        Reporte r = map.get(tipo);
        if (r == null) {
            throw new IllegalArgumentException("Reporte no registrado: " + tipo);
        }
        return r;
    }
}
