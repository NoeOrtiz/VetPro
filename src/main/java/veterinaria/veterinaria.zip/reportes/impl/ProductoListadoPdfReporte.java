package veterinaria.reportes.impl;

import javax.swing.JTable;
import javax.swing.table.TableModel;

import org.apache.pdfbox.pdmodel.font.PDType1Font;

import veterinaria.reportes.core.ReporteRequest;
import veterinaria.reportes.core.ReporteTipo;
import veterinaria.reportes.pdf.AbstractPdfReporte;
import veterinaria.reportes.pdf.PdfDocument;
import veterinaria.reportes.pdf.PdfStyle;

/**
 * Reporte PDF: Listado de Productos.
 */
public class ProductoListadoPdfReporte extends AbstractPdfReporte {

    @Override
    public ReporteTipo tipo() {
        return ReporteTipo.PRODUCTO_LISTADO;
    }

    @Override
    protected String titulo() {
        return "INFORME - LISTA DE PRODUCTOS";
    }

    @Override
    protected boolean isLandscape() {
        return true; // A4 horizontal
    }

    @Override
    protected void validar(ReporteRequest request) throws Exception {
        JTable tabla = request.get("tabla", JTable.class);
        if (tabla == null || tabla.getRowCount() == 0) {
            throw new Exception("No hay productos para imprimir.");
        }
    }

    @Override
    protected void renderBody(PdfDocument pdf, ReporteRequest request) throws Exception {
        JTable tabla = request.get("tabla", JTable.class);
        TableModel m = tabla.getModel();

        pdf.text(PdfStyle.TXT_FONT, 10, pdf.getMargin(), pdf.getY(), "Total de productos listados: " + m.getRowCount());
        pdf.down(16f);

        // Columnas en FormProducto:
        // 0 Seleccionar | 1 ID | 2 Código | 3 Nombre | 4 Rubro | 5 Descripción | 6 Precio | 7 IVA | 8 Descuento | 9 Unidad de Medida | 10 Proveedor | 11 Stock
        int colId = 1;
        int colCodigo = 2;
        int colNombre = 3;
        int colRubro = 4;
        int colDesc = 5;
        int colPrecio = 6;
        int colIva = 7;
        int colDto = 8;
        int colUM = 9;
        int colProv = 10;
        int colStock = 11;

        final int fontSize = 9;
        final float lineH = 11f;

        final float[] w = new float[] {
            35f,   // ID
            60f,   // Código
            95f,   // Nombre
            70f,   // Rubro
            155f,  // Descripción
            55f,   // Precio
            40f,   // IVA
            55f,   // Dto
            65f,   // UM
            110f,  // Proveedor
            45f    // Stock
        };

        float x = pdf.getMargin();
        final float[] cx = new float[w.length];
        cx[0] = x;
        for (int i = 1; i < w.length; i++) {
            cx[i] = cx[i - 1] + w[i - 1];
        }

        pdf.ensureSpace(60f);
        pdf.text(PDType1Font.HELVETICA_BOLD, fontSize, cx[0], pdf.getY(), "ID");
        pdf.text(PDType1Font.HELVETICA_BOLD, fontSize, cx[1], pdf.getY(), "CÓD.");
        pdf.text(PDType1Font.HELVETICA_BOLD, fontSize, cx[2], pdf.getY(), "NOMBRE");
        pdf.text(PDType1Font.HELVETICA_BOLD, fontSize, cx[3], pdf.getY(), "RUBRO");
        pdf.text(PDType1Font.HELVETICA_BOLD, fontSize, cx[4], pdf.getY(), "DESCRIPCIÓN");
        pdf.text(PDType1Font.HELVETICA_BOLD, fontSize, cx[5], pdf.getY(), "PRECIO");
        pdf.text(PDType1Font.HELVETICA_BOLD, fontSize, cx[6], pdf.getY(), "IVA");
        pdf.text(PDType1Font.HELVETICA_BOLD, fontSize, cx[7], pdf.getY(), "DTO");
        pdf.text(PDType1Font.HELVETICA_BOLD, fontSize, cx[8], pdf.getY(), "U.M.");
        pdf.text(PDType1Font.HELVETICA_BOLD, fontSize, cx[9], pdf.getY(), "PROVEEDOR");
        pdf.text(PDType1Font.HELVETICA_BOLD, fontSize, cx[10], pdf.getY(), "STOCK");
        pdf.down(10f);
        pdf.line();

        for (int r = 0; r < m.getRowCount(); r++) {
            String id = safe(m.getValueAt(r, colId));
            String codigo = safe(m.getValueAt(r, colCodigo));
            String nombre = safe(m.getValueAt(r, colNombre));
            String rubro = safe(m.getValueAt(r, colRubro));
            String desc = safe(m.getValueAt(r, colDesc));
            String precio = safe(m.getValueAt(r, colPrecio));
            String iva = safe(m.getValueAt(r, colIva));
            String dto = safe(m.getValueAt(r, colDto));
            String um = safe(m.getValueAt(r, colUM));
            String prov = safe(m.getValueAt(r, colProv));
            String stock = safe(m.getValueAt(r, colStock));

            pdf.ensureSpace(20f);

            pdf.text(PdfStyle.TXT_FONT, fontSize, cx[0], pdf.getY(), id);
            pdf.text(PdfStyle.TXT_FONT, fontSize, cx[1], pdf.getY(), truncate(codigo, 12));
            pdf.text(PdfStyle.TXT_FONT, fontSize, cx[2], pdf.getY(), truncate(nombre, 22));
            pdf.text(PdfStyle.TXT_FONT, fontSize, cx[3], pdf.getY(), truncate(rubro, 14));
            pdf.text(PdfStyle.TXT_FONT, fontSize, cx[4], pdf.getY(), truncate(desc, 40));
            pdf.text(PdfStyle.TXT_FONT, fontSize, cx[5], pdf.getY(), truncate(precio, 12));
            pdf.text(PdfStyle.TXT_FONT, fontSize, cx[6], pdf.getY(), truncate(iva, 8));
            pdf.text(PdfStyle.TXT_FONT, fontSize, cx[7], pdf.getY(), truncate(dto, 10));
            pdf.text(PdfStyle.TXT_FONT, fontSize, cx[8], pdf.getY(), truncate(um, 10));
            pdf.text(PdfStyle.TXT_FONT, fontSize, cx[9], pdf.getY(), truncate(prov, 20));
            pdf.text(PdfStyle.TXT_FONT, fontSize, cx[10], pdf.getY(), truncate(stock, 8));

            pdf.down(lineH);
        }

        pdf.line();
    }

    private String safe(Object o) {
        if (o == null) return "";
        String s = String.valueOf(o);
        return (s == null) ? "" : s;
    }

    private String truncate(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return s.substring(0, Math.max(0, max - 1)) + "…";
    }
}
