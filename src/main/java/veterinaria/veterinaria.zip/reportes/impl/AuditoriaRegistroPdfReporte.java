package veterinaria.reportes.impl;

/**
 * Clase de compatibilidad.
 *
 * En versiones anteriores se referenciaba un "AUDITORIA_REGISTRO" que no existe
 * en el enum ReporteTipo. Este proyecto usa:
 * - ReporteTipo.AUDITORIA_EVENTO (detalle)
 * - ReporteTipo.AUDITORIA_LISTADO (listado)
 *
 * No se registra en ReporteRegistry, pero se deja para evitar fallos de compilación
 * si alguna clase lo referencia.
 */
public class AuditoriaRegistroPdfReporte extends AuditoriaEventoPdfReporte {
    // Intencionalmente vacío.
}
