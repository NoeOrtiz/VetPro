package veterinaria.reportes.impl;

import javax.swing.JOptionPane;
import javax.swing.JTable;

import veterinaria.reportes.core.ReporteRequest;
import veterinaria.reportes.core.ReporteService;
import veterinaria.reportes.core.ReporteTipo;

/**
 * Helper UI para mantener compatibilidad con llamados históricos, pero usando
 * el framework unificado de reportes.
 */
public final class HistorialTurnosImpresion {

    private HistorialTurnosImpresion() {
    }

    public static void imprimir(JTable tabla, String filtrosResumen) {
        if (tabla == null || tabla.getModel() == null || tabla.getRowCount() == 0) {
            JOptionPane.showMessageDialog(null,
                    "No hay datos para imprimir.",
                    "Imprimir Historial de Turnos",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        Object[] options = {"Compacta", "Detallada", "Cancelar"};
        int choice = JOptionPane.showOptionDialog(
                null,
                "Seleccioná el formato de impresión:",
                "Imprimir Historial de Turnos",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
        );

        if (choice == 2 || choice == JOptionPane.CLOSED_OPTION) {
            return;
        }

        ReporteTipo tipo = (choice == 0)
                ? ReporteTipo.HISTORIAL_TURNOS_LISTADO
                : ReporteTipo.HISTORIAL_TURNOS;

        try {
            ReporteRequest req = new ReporteRequest()
                    .put("tabla", tabla)
                    .put("filtros", filtrosResumen != null ? filtrosResumen : "");

            new ReporteService().generar(tipo, req);

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null,
                    "No se pudo generar el reporte. " + ex.getMessage(),
                    "Imprimir Historial de Turnos",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
