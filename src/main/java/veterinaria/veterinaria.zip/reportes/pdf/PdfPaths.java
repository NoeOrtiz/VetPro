
package veterinaria.reportes.pdf;

import java.io.File;

/**
 * Resuelve rutas de salida para PDFs.
 */
public class PdfPaths {

    private PdfPaths() {}

    public static File enDescargas(String fileName) {
        String home = System.getProperty("user.home");
        File downloads = new File(home, "Downloads");
        if (!downloads.exists()) {
            downloads = new File(home, "Descargas");
        }
        if (!downloads.exists()) {
            downloads = new File(home);
        }
        return new File(downloads, fileName);
    }
}
