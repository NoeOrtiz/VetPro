
package veterinaria.reportes.pdf;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;

/**
 * Wrapper simple (Facade) sobre PDFBox para simplificar:
 * - creación de páginas (portrait/landscape)
 * - control de margen y cursor Y
 * - helpers de texto y líneas
 */
public class PdfDocument implements Closeable {

    private final PDDocument doc;
    private final PDRectangle baseRect;
    private final boolean landscape;

    private PDPage page;
    private PDPageContentStream cs;

    private float margin = 50f;
    private float y;
    private float pageW;
    private float pageH;

    public PdfDocument() throws IOException {
        this(PDRectangle.A4, false);
    }

    public PdfDocument(boolean landscape) throws IOException {
        this(PDRectangle.A4, landscape);
    }

    public PdfDocument(PDRectangle baseRect, boolean landscape) throws IOException {
        this.doc = new PDDocument();
        this.baseRect = baseRect != null ? baseRect : PDRectangle.A4;
        this.landscape = landscape;
        nuevaPagina();
    }

    private PDRectangle currentRect() {
        if (!landscape) return baseRect;
        // Intercambia ancho/alto para A4 horizontal
        return new PDRectangle(baseRect.getHeight(), baseRect.getWidth());
    }

    public void nuevaPagina() throws IOException {
        if (cs != null) cs.close();

        page = new PDPage(currentRect());
        doc.addPage(page);
        cs = new PDPageContentStream(doc, page);

        pageW = page.getMediaBox().getWidth();
        pageH = page.getMediaBox().getHeight();
        y = pageH - margin;
    }

    public float getMargin() { return margin; }
    public float getY() { return y; }
    public float getPageW() { return pageW; }
    public float getPageH() { return pageH; }

    public void setY(float y) { this.y = y; }


    public void rect(float x, float y, float w, float h) throws IOException {
        cs.addRect(x, y, w, h);
        cs.stroke();
    }

    public void line() throws IOException {
        cs.moveTo(margin, y);
        cs.lineTo(pageW - margin, y);
        cs.stroke();
        y -= 12f;
    }

    public void text(PDFont font, int size, float x, float y, String t) throws IOException {
        cs.beginText();
        cs.setFont(font, size);
        cs.newLineAtOffset(x, y);
        cs.showText(t != null ? t : "");
        cs.endText();
    }

    public void textLeft(PDFont font, int size, float x, String t) throws IOException {
        text(font, size, x, y, t);
    }

    public void textRight(PDFont font, int size, float xRight, String t) throws IOException {
        String s = t != null ? t : "";
        float w = font.getStringWidth(s) / 1000f * size;
        text(font, size, xRight - w, y, s);
    }

    /**
     * Mide el ancho (en puntos) de un texto para una fuente/tamaño.
     */
    public float textWidth(PDFont font, int size, String t) throws IOException {
        String s = (t != null) ? t : "";
        return font.getStringWidth(s) / 1000f * size;
    }

    /**
     * Envuelve (wrap) un texto dentro de un ancho máximo.
     * - Respeta saltos de línea existentes.
     * - Corta palabras muy largas si exceden el ancho.
     */
    public List<String> wrapText(PDFont font, int size, String text, float maxWidth) throws IOException {
        List<String> out = new ArrayList<>();
        if (text == null) {
            out.add("");
            return out;
        }
        String[] paragraphs = text.replace("\r", "").split("\n", -1);
        for (String p : paragraphs) {
            String s = (p == null) ? "" : p.trim();
            if (s.isEmpty()) {
                out.add("");
                continue;
            }

            String[] words = s.split("\\s+");
            StringBuilder line = new StringBuilder();
            for (String w : words) {
                if (w == null || w.isEmpty()) continue;

                // Si la palabra sola ya excede el ancho, la cortamos por caracteres.
                if (textWidth(font, size, w) > maxWidth) {
                    // Flush de la línea actual
                    if (line.length() > 0) {
                        out.add(line.toString());
                        line.setLength(0);
                    }
                    out.addAll(splitLongWord(font, size, w, maxWidth));
                    continue;
                }

                String candidate = (line.length() == 0) ? w : (line + " " + w);
                if (textWidth(font, size, candidate) <= maxWidth) {
                    line.setLength(0);
                    line.append(candidate);
                } else {
                    out.add(line.toString());
                    line.setLength(0);
                    line.append(w);
                }
            }
            if (line.length() > 0) out.add(line.toString());
        }
        if (out.isEmpty()) out.add("");
        return out;
    }

    private List<String> splitLongWord(PDFont font, int size, String word, float maxWidth) throws IOException {
        List<String> parts = new ArrayList<>();
        if (word == null || word.isEmpty()) {
            parts.add("");
            return parts;
        }
        StringBuilder chunk = new StringBuilder();
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            String candidate = chunk.toString() + c;
            if (textWidth(font, size, candidate) <= maxWidth) {
                chunk.append(c);
            } else {
                if (chunk.length() > 0) parts.add(chunk.toString());
                chunk.setLength(0);
                chunk.append(c);
            }
        }
        if (chunk.length() > 0) parts.add(chunk.toString());
        return parts;
    }

    public void down(float dy) { y -= dy; }

    public void ensureSpace(float needed) throws IOException {
        if (y - needed < margin) {
            nuevaPagina();
        }
    }

    public void save(File out) throws IOException {
        cs.close();
        doc.save(out);
    }

    @Override
    public void close() throws IOException {
        if (cs != null) cs.close();
        doc.close();
    }
}
