
package veterinaria.reportes.pdf;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.pdfbox.pdmodel.common.PDRectangle;

import veterinaria.reportes.core.Reporte;
import veterinaria.reportes.core.ReporteRequest;

public abstract class AbstractPdfReporte implements Reporte {

    protected static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

    @Override
    public final File generar(ReporteRequest request) throws Exception {
        validar(request);

        File out = buildOutputFile(request);

        try (PdfDocument pdf = new PdfDocument(pageSize(), isLandscape())) {
            renderHeader(pdf, request);
            renderBody(pdf, request);
            renderFooter(pdf, request);
            pdf.save(out);
        }

        return out;
    }

    /**
     * Tamaño base de página. Por defecto A4.
     */
    protected PDRectangle pageSize() {
        return PDRectangle.A4;
    }

    /**
     * Orientación del reporte. Por defecto vertical.
     */
    protected boolean isLandscape() {
        return false;
    }

    protected void validar(ReporteRequest request) throws Exception {
        // por defecto no hace nada
    }

    protected File buildOutputFile(ReporteRequest request) {
        String fileName = tipo().name() + "_" + LocalDateTime.now().format(TS) + ".pdf";
        return PdfPaths.enDescargas(fileName);
    }

    protected void renderHeader(PdfDocument pdf, ReporteRequest request) throws Exception {
        pdf.text(PdfStyle.H1_FONT, 14, pdf.getMargin(), pdf.getY(), "Veterinaria Dogtor Cat");
        pdf.down(18f);
        pdf.text(PdfStyle.H2_FONT, 12, pdf.getMargin(), pdf.getY(), titulo());
        pdf.down(14f);
        pdf.line();
    }

    protected void renderFooter(PdfDocument pdf, ReporteRequest request) throws Exception {
        // opcional
    }

    protected abstract String titulo();
    protected abstract void renderBody(PdfDocument pdf, ReporteRequest request) throws Exception;
}
