package veterinaria.util.jaspersoft;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;

public class ReportManagerDAO {

    private static final Logger logger = Logger.getLogger(ReportManagerDAO.class.getName());
    private final Conexion cx = new Conexion();

    /**
     * Exporta el reporte a PDF en la ruta especificada.
     *
     * @param reporteStream Stream del archivo .jasper
     * @param parametros    Mapa de parámetros para el reporte
     * @param outputPath    Ruta de salida del archivo PDF
     * @throws JRException En caso de error al exportar el reporte
     */
    public void exportarReporteAPDF(InputStream reporteStream, Map<String, Object> parametros, String outputPath) throws JRException {
        JasperPrint jasperPrint = generarReporteConConexion(reporteStream, parametros);

        JRPdfExporter exportador = new JRPdfExporter();
        exportador.setExporterInput(new SimpleExporterInput(jasperPrint));
        exportador.setExporterOutput(new SimpleOutputStreamExporterOutput(outputPath));

        exportador.exportReport();
        logger.log(Level.INFO, "Reporte exportado a PDF en: {0}", outputPath);
    }

    /**
     * Genera el reporte llenando los datos en el JasperPrint.
     *
     * @param reporteStream Stream del archivo .jasper
     * @param parametros    Mapa de parámetros para el reporte
     * @return Objeto JasperPrint que representa el reporte con datos
     * @throws JRException En caso de error al generar el reporte
     */
    public JasperPrint generarReporteConConexion(InputStream reporteStream, Map<String, Object> parametros) throws JRException {
        Connection conexion = null;

        try {
            Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
            conexion = cx.obtenerConexion();
            JasperReport reporte = (JasperReport) JRLoader.loadObject(reporteStream);
            return JasperFillManager.fillReport(reporte, parametros, conexion);
        } catch (JRException ex) {
            logger.log(Level.SEVERE, "Error Jasper al generar el reporte.", ex);
            throw ex;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Error general al generar el reporte.", ex);
            throw new JRException("No fue posible generar el reporte. Verifique la conexión a la base y el archivo Jasper.", ex);
        } finally {
            Conexion.cerrarConexion(conexion);
        }
    }

    /**
     * Obtiene el directorio de descargas del usuario.
     *
     * @return La ruta del directorio de descargas
     */
    public String obtenerDirectorioDescargas() {
        return System.getProperty("user.home") + "/Descargas";
    }
}
