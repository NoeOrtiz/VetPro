package veterinaria.util.jaspersoft;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import veterinaria.config.PersistenceConfig;

public final class Conexion {

    private static final Logger LOG = Logger.getLogger(Conexion.class.getName());
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

    public Connection obtenerConexion() {
        try {
            Class.forName(DRIVER);
            Connection connection = DriverManager.getConnection(
                    PersistenceConfig.getDbUrl(),
                    PersistenceConfig.getDbUser(),
                    PersistenceConfig.getDbPassword()
            );
            LOG.info("Conexión Jasper/MySQL creada correctamente.");
            return connection;
        } catch (ClassNotFoundException ex) {
            throw new IllegalStateException("No se pudo cargar el driver JDBC de MySQL.", ex);
        } catch (SQLException ex) {
            throw new IllegalStateException("No se pudo abrir la conexión JDBC para reportes. Config actual: "
                    + PersistenceConfig.describeSafe(), ex);
        }
    }

    public static void cerrarConexion(Connection connection) {
        if (connection == null) {
            return;
        }
        try {
            if (!connection.isClosed()) {
                connection.close();
                LOG.info("Conexión Jasper/MySQL cerrada.");
            }
        } catch (SQLException ex) {
            LOG.log(Level.WARNING, "Error al cerrar la conexión JDBC de reportes.", ex);
        }
    }
}
