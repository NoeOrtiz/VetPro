package veterinaria.util.impresion;

import javax.swing.JTable;

/**
 * @deprecated Duplicado histórico. Se conserva únicamente para compatibilidad.
 * <p>
 * Usar {@link veterinaria.reportes.impl.HistorialTurnosImpresion} o, preferentemente,
 * el framework de reportes ({@code ReporteService}).
 */
@Deprecated
public final class HistorialTurnosImpresion {

    private HistorialTurnosImpresion() {
    }

    public static void imprimir(JTable tabla, String filtrosResumen) {
        veterinaria.reportes.impl.HistorialTurnosImpresion.imprimir(tabla, filtrosResumen);
    }
}
