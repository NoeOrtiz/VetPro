package veterinaria.util;

import veterinaria.entidad.EstadoPeluqueriaEnum;

/**
 * Puente de compatibilidad para estados de Peluqueria.
 *
 * Objetivo:
 * - Centralizar los estados como {@link EstadoPeluqueriaEnum} (tipado fuerte).
 * - Evitar literales String repartidos por el proyecto.
 * - Mantener helpers útiles (esTerminal / esNoEditable) sin romper llamadas existentes.
 *
 * Nota:
 * Si el proyecto ya migró completamente a EstadoPeluqueriaEnum, este helper puede
 * mantenerse como utilitario o eliminarse en una etapa posterior.
 */
public final class PeluqueriaEstados {

    private PeluqueriaEstados() {
    }

    // Estados tipados (recomendado usar estos en todo el proyecto)
    public static final EstadoPeluqueriaEnum PENDIENTE  = EstadoPeluqueriaEnum.PENDIENTE;
    public static final EstadoPeluqueriaEnum CONFIRMADO = EstadoPeluqueriaEnum.CONFIRMADO;
    public static final EstadoPeluqueriaEnum CANCELADO  = EstadoPeluqueriaEnum.CANCELADO;
    public static final EstadoPeluqueriaEnum ELIMINADO  = EstadoPeluqueriaEnum.ELIMINADO;
    public static final EstadoPeluqueriaEnum COMPLETADO = EstadoPeluqueriaEnum.COMPLETADO;

    /** Turnos "cerrados" / historial */
    public static boolean esTerminal(EstadoPeluqueriaEnum estado) {
        return estado == EstadoPeluqueriaEnum.ELIMINADO
                || estado == EstadoPeluqueriaEnum.CANCELADO
                || estado == EstadoPeluqueriaEnum.COMPLETADO;
    }

    /** Turnos que no deberían poder editarse desde formularios */
    public static boolean esNoEditable(EstadoPeluqueriaEnum estado) {
        return estado == EstadoPeluqueriaEnum.ELIMINADO || estado == EstadoPeluqueriaEnum.CANCELADO;
    }

    // ------------------------------------------------------------
    // Backward compatibility (si todavía queda algún String suelto)
    // ------------------------------------------------------------

    public static boolean esTerminal(String estado) {
        return esTerminal(parse(estado));
    }

    public static boolean esNoEditable(String estado) {
        return esNoEditable(parse(estado));
    }

    /**
     * Parsea un texto de estado a {@link EstadoPeluqueriaEnum}.
     * Acepta: "Pendiente", "PENDIENTE", "Confirmado", etc.
     */
    public static EstadoPeluqueriaEnum parse(String estado) {
        if (estado == null) return null;
        String s = estado.trim();
        if (s.isEmpty()) return null;

        // Normalizar
        String up = s.toUpperCase();

        // Aceptar nombres del enum
        try {
            return EstadoPeluqueriaEnum.valueOf(up);
        } catch (Exception ignore) {
        }

        // Aceptar labels humanos (BD histórica)
        if ("PENDIENTE".equals(up) || "PENDIENTE".equals(up)) return EstadoPeluqueriaEnum.PENDIENTE;
        if ("CONFIRMADO".equals(up)) return EstadoPeluqueriaEnum.CONFIRMADO;
        if ("CANCELADO".equals(up)) return EstadoPeluqueriaEnum.CANCELADO;
        if ("ELIMINADO".equals(up)) return EstadoPeluqueriaEnum.ELIMINADO;
        if ("COMPLETADO".equals(up)) return EstadoPeluqueriaEnum.COMPLETADO;

        // Aceptar capitalizado típico
        if ("PENDIENTE".equals(up)) return EstadoPeluqueriaEnum.PENDIENTE;
        if ("CONFIRMADO".equals(up)) return EstadoPeluqueriaEnum.CONFIRMADO;
        if ("CANCELADO".equals(up)) return EstadoPeluqueriaEnum.CANCELADO;
        if ("ELIMINADO".equals(up)) return EstadoPeluqueriaEnum.ELIMINADO;
        if ("COMPLETADO".equals(up)) return EstadoPeluqueriaEnum.COMPLETADO;

        return null;
    }
}
