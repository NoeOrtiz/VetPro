package veterinaria.util.enums;

/**
 * Enumeración de tipos de método de pago.
 *
 * Nota: se conserva la etiqueta EXACTA utilizada históricamente en BD/GUI.
 */
public enum MetodoPagoTipo {

    EFECTIVO("Pago Efectivo"),
    CUENTA_CORRIENTE("Cuenta Corriente"),
    TARJETA_CREDITO("Tarjeta de Crédito"),
    // Se mantiene el texto tal cual estaba en Constantes ("Dédito") por compatibilidad con datos existentes.
    TARJETA_DEBITO("Tarjeta de Dédito");

    private final String etiqueta;

    MetodoPagoTipo(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    @Override
    public String toString() {
        return etiqueta;
    }

    public static MetodoPagoTipo fromEtiqueta(String value) {
        if (value == null) {
            return null;
        }
        String v = value.trim();
        for (MetodoPagoTipo t : values()) {
            if (t.etiqueta.equalsIgnoreCase(v)) {
                return t;
            }
        }
        return null;
    }
}
