package veterinaria.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

/**
 * Utilidades para manejar montos de dinero de forma segura.
 *
 * <p>
 * - Parseo tolerante a formatos argentinos: "1.234,56" / "1234,56" / "1234.56".
 * - Formateo consistente con 2 decimales.
 * - Siempre devuelve BigDecimal con escala 2.
 */
public final class MoneyUtil {

    private static final Locale LOCALE_AR = new Locale("es", "AR");
    private static final Locale LOCALE_US = Locale.US;

    // Formato estándar: 2 decimales, separador decimal '.', sin separador de miles.
    private static final DecimalFormat DF_STD;

    static {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(LOCALE_US);
        symbols.setDecimalSeparator('.');
        // Sin separador de miles
        symbols.setGroupingSeparator('\0');
        DF_STD = new DecimalFormat("0.00", symbols);
        DF_STD.setGroupingUsed(false);
    }

    private MoneyUtil() {
    }

    public static BigDecimal parse(String raw) {
        if (raw == null) {
            throw new IllegalArgumentException("Monto vacío");
        }
        String s = raw.trim();
        if (s.isEmpty()) {
            throw new IllegalArgumentException("Monto vacío");
        }

        // Quitar símbolos comunes
        s = s.replace("$", "");
        s = s.replace("AR$", "");
        s = s.replace(" ", "");

        // Normalizar separadores: si hay '.' y ',' asumimos '.' miles y ',' decimal.
        if (s.contains(",") && s.contains(".")) {
            s = s.replace(".", "");
            s = s.replace(",", ".");
        } else if (s.contains(",")) {
            // Si solo hay coma, es decimal
            s = s.replace(",", ".");
        }

        BigDecimal bd;
        try {
            bd = new BigDecimal(s);
        } catch (NumberFormatException ex) {
            // fallback: intentar parseo por NumberFormat (por si vienen separadores raros)
            try {
                NumberFormat nf = NumberFormat.getNumberInstance(LOCALE_AR);
                Number n = nf.parse(raw);
                bd = BigDecimal.valueOf(n.doubleValue());
            } catch (ParseException pe) {
                throw new IllegalArgumentException("Monto inválido: " + raw);
            }
        }

        return bd.setScale(2, RoundingMode.HALF_UP);
    }

    public static BigDecimal of(Double value) {
        if (value == null) {
            return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        }
        return BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP);
    }

    public static BigDecimal percent(String rawPercent) {
        // "21" => 0.21
        BigDecimal p = parse(rawPercent);
        return p.divide(BigDecimal.valueOf(100), 6, RoundingMode.HALF_UP);
    }

    public static String format(BigDecimal value) {
        BigDecimal v = (value == null ? BigDecimal.ZERO : value).setScale(2, RoundingMode.HALF_UP);
        NumberFormat nf = NumberFormat.getNumberInstance(LOCALE_AR);
        nf.setMinimumFractionDigits(2);
        nf.setMaximumFractionDigits(2);
        return nf.format(v);
    }

    /**
     * Formato estándar para inputs/cálculos (sin moneda, sin miles): 12075.00
     */
    public static String formatStandard(BigDecimal value) {
        BigDecimal v = (value == null ? BigDecimal.ZERO : value).setScale(2, RoundingMode.HALF_UP);
        return DF_STD.format(v);
    }


    public static BigDecimal scale(BigDecimal value, int decimals, RoundingMode mode) {
        if (decimals < 0) decimals = 0;
        if (mode == null) mode = RoundingMode.HALF_UP;
        BigDecimal v = (value == null ? BigDecimal.ZERO : value);
        return v.setScale(decimals, mode);
    }

    public static String format(BigDecimal value, int decimals, RoundingMode mode) {
        BigDecimal v = scale(value, decimals, mode);
        NumberFormat nf = NumberFormat.getNumberInstance(LOCALE_AR);
        nf.setMinimumFractionDigits(decimals);
        nf.setMaximumFractionDigits(decimals);
        return nf.format(v);
    }
}
