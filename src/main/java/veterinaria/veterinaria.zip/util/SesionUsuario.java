package veterinaria.util;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import veterinaria.controlador.PermisoControlador;
import veterinaria.entidad.Permiso;
import veterinaria.entidad.Rol;
import veterinaria.entidad.RolPermiso;
import veterinaria.entidad.Usuario;
import veterinaria.persistencia.PermisoDAO;
import veterinaria.util.Constantes;

/**
 * Sesión de usuario y control unificado de permisos.
 *
 * Regla actual (segura y práctica):
 *  - Si el usuario es Administrador: puede acceder siempre.
 *  - Si el permiso NO existe en el sistema (tabla permiso): se DENIEGA a no-administradores.
 *  - Si el permiso existe: exige que el rol tenga acceso=true (tabla rol_permiso).
 */
public class SesionUsuario {

    private static SesionUsuario instancia;
    private Usuario usuario;
    private Rol rol;
    private List<RolPermiso> permisos;          // permisos asignados al rol (rol_permiso)
    private Set<String> permisosSistema;        // permisos existentes en el sistema (tabla permiso)
    private String estado;
    private String nombreApellido;

    private SesionUsuario() {}

    public static SesionUsuario getInstancia() {
        if (instancia == null) {
            instancia = new SesionUsuario();
        }
        return instancia;
    }

    public void iniciarSesion(Usuario usuario) {
        this.usuario = usuario;
        this.rol = (usuario != null) ? usuario.getRol() : null;
        cargarPermisos();
        this.estado = "Usuario Logeado";
        if (usuario != null && usuario.getPersona() != null) {
            this.nombreApellido = usuario.getPersona().getNombre() + " " + usuario.getPersona().getApellido();
        } else {
            this.nombreApellido = null;
        }
    }

    private void cargarPermisos() {
        // 1) permisos asignados al rol
        PermisoControlador permisoControlador = new PermisoControlador();
        this.permisos = (this.rol != null) ? permisoControlador.obtenerPermisosParaSesion(this.rol) : null;

        // 2) permisos existentes en el sistema (tabla permiso)
        this.permisosSistema = new HashSet<>();
        try {
            PermisoDAO dao = new PermisoDAO();
            List<Permiso> todos = dao.obtenerPermisos();
            if (todos != null) {
                for (Permiso p : todos) {
                    if (p != null && p.getNombrePermiso() != null) {
                        permisosSistema.add(p.getNombrePermiso().trim().toLowerCase());
                    }
                }
            }
        } catch (Exception e) {
            // Si falla la carga, por seguridad NO se permite a no-admin en permisos no definidos
            AppLog.error(SesionUsuario.class, "Error al cargar permisos del sistema", e);
        }
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Rol getRol() {
        return rol;
    }

    public List<RolPermiso> getPermisos() {
        return permisos;
    }

    public void cerrarSesion() {
        usuario = null;
        rol = null;
        permisos = null;
        permisosSistema = null;
        estado = null;
        nombreApellido = null;
    }

    public String getNombreApellido() {
        return nombreApellido;
    }

    private boolean isAdministrador() {
        // Rol Administrador (idRol = 1)
        if (rol != null && rol.getIdRol() != null && rol.getIdRol() == 1) {
            return true;
        }
        // Fallback por nombre (por compatibilidad)
        return rol != null
                && rol.getNombreRol() != null
                && "Administrador".equalsIgnoreCase(rol.getNombreRol().trim());
    }

    private Set<String> aliasesPermiso(String nombrePermiso) {
        Set<String> aliases = new HashSet<>();
        if (nombrePermiso == null) {
            return aliases;
        }
        String key = nombrePermiso.trim();
        if (key.isEmpty()) {
            return aliases;
        }
        aliases.add(key);
        if ("ClassConfig".equalsIgnoreCase(key)) {
            aliases.add("FormConfiguracion");
        } else if ("FormConfiguracion".equalsIgnoreCase(key)) {
            aliases.add("ClassConfig");
        }
        return aliases;
    }

    public boolean tienePermiso(String nombrePermiso) {
        if (permisos == null || nombrePermiso == null) return false;
        final Set<String> buscados = aliasesPermiso(nombrePermiso);
        return permisos.stream().anyMatch(rp ->
            rp != null &&
            rp.getPermiso() != null &&
            rp.getPermiso().getNombrePermiso() != null &&
            buscados.stream().anyMatch(alias -> alias.equalsIgnoreCase(rp.getPermiso().getNombrePermiso())) &&
            Boolean.TRUE.equals(rp.getAcceso())
        );
    }

    /**
     * Indica si el permiso existe en el sistema (tabla permiso).
     */
    public boolean isPermisoEnSistema(String nombrePermiso) {
        if (nombrePermiso == null) return false;
        if (permisosSistema == null) return false;
        for (String alias : aliasesPermiso(nombrePermiso)) {
            if (permisosSistema.contains(alias.trim().toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    public boolean puede(String nombrePermiso) {
        if (nombrePermiso == null) return false;
        String key = nombrePermiso.trim();
        if (key.isEmpty()) return false;

        if (isAdministrador()) {
            if (!isPermisoEnSistema(key)) {
                try {
                    PermisoControlador pc = new PermisoControlador();
                    if (permisosSistema != null) {
                        for (String alias : aliasesPermiso(key)) {
                            permisosSistema.add(alias.toLowerCase());
                        }
                    }
                } catch (Exception ex) {
                    AppLog.error(SesionUsuario.class, "Error al autoprovisionar permiso para administrador", ex);
                }
            }
            return true;
        }

        // No-admin: si el permiso no está registrado en la tabla permiso, se deniega por seguridad
        if (!isPermisoEnSistema(key)) {
            return false;
        }

        // Si está registrado, exige acceso=true en rol_permiso
        return tienePermiso(key);
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
