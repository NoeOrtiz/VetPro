package veterinaria.util.state;

import java.util.List;
import veterinaria.entidad.RolPermiso;
import veterinaria.util.SesionUsuario;

/**
 * Estado para rol Veterinario.
 *
 * Nota: actualmente el chequeo real de permisos proviene de la sesión
 * (SesionUsuario.getPermisos()), por lo que este estado mantiene la
 * misma lógica que los demás estados.
 */
public class EstadoVeterinario implements EstadoUsuario {

    private static final SesionUsuario sesionUsuario = SesionUsuario.getInstancia();
    private final List<RolPermiso> rolPermisos;

    public EstadoVeterinario(List<RolPermiso> rolPermisos) {
        this.rolPermisos = rolPermisos;
    }

    @Override
    public boolean tienePermiso(String nombrePermiso) {

        List<RolPermiso> rolPermisosUsuario = sesionUsuario.getPermisos();
        for (RolPermiso rolPermiso : rolPermisosUsuario) {
            String permisoActual = rolPermiso.getPermiso().getNombrePermiso();
            boolean acceso = rolPermiso.getAcceso();

            if (permisoActual.equals(nombrePermiso) && acceso) {
                return true;
            }
        }
        return false;
    }
}
