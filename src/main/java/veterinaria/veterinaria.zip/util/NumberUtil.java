package veterinaria.util;

/**
 * Utilidades de parseo numérico para inputs de UI.
 *
 * <p>Objetivo: evitar {@link NumberFormatException} por separadores locales
 * (puntos de miles, comas decimales, espacios, etc.) y centralizar el criterio.
 */
public final class NumberUtil {

    private NumberUtil() {
    }

    /**
     * Parsea un entero tolerando separadores comunes.
     *
     * <p>Ejemplos válidos: "1.234" "1234" "1 234".
     */
    public static int parseInt(String raw) {
        if (raw == null) {
            throw new IllegalArgumentException("Número vacío");
        }
        String s = raw.trim();
        if (s.isEmpty()) {
            throw new IllegalArgumentException("Número vacío");
        }
        // Remover separadores de miles y espacios
        s = s.replace(" ", "").replace(".", "");
        // Si llegó con coma decimal, cortamos parte decimal (cantidad debe ser entera)
        int comma = s.indexOf(',');
        if (comma >= 0) {
            s = s.substring(0, comma);
        }
        // Si llegó con punto decimal (caso raro), cortamos
        int dot = s.indexOf('.');
        if (dot >= 0) {
            s = s.substring(0, dot);
        }
        return Integer.parseInt(s);
    }

    /**
     * Parsea un entero positivo (> 0).
     */
    public static int parsePositiveInt(String raw) {
        int v = parseInt(raw);
        if (v <= 0) {
            throw new IllegalArgumentException("El número debe ser mayor a 0");
        }
        return v;
    }
}
