
package veterinaria.util;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.util.function.Supplier;

/**
 * Utilidad centralizada para manejo común de JTable:
 * - Selección única en columna checkbox
 * - Tooltips por valor de celda o por descripción de columna
 * - Filtro y resaltado por búsqueda
 */
public class ManejoTablas {

    /**
     * Asegura que sólo una fila pueda tener seleccionado el checkbox de la columna 0.
     * Ideal para tablas con columna "Seleccionar".
     */
    public void asegurarSeleccionUnica(JTable table) {
        if (table == null || table.getModel() == null) return;

        table.getModel().addTableModelListener(e -> {
            if (e.getColumn() == 0) {  // Columna del checkbox (columna 0)
                int rowCount = table.getRowCount();
                for (int i = 0; i < rowCount; i++) {
                    if (i != e.getFirstRow() && Boolean.TRUE.equals(table.getValueAt(i, 0))) {
                        table.setValueAt(false, i, 0);  // Deselecciona cualquier otra fila
                    }
                }
            }
        });
    }

    /**
     * Devuelve el índice (en vista) de la fila que tiene el checkbox seleccionado (columna 0),
     * o -1 si no hay ninguna.
     */
    public Integer comprobarElementoSeleccionado(JTable table) {
        // IMPORTANTE:
        // En algunos momentos (ej. cuando se hace model.setRowCount(0) y hay RowSorter activo)
        // la JTable puede reportar temporalmente filas en VISTA mientras el MODELO ya quedó vacío.
        // Si usamos table.getValueAt(viewRow, 0) en ese instante, puede disparar
        // ArrayIndexOutOfBoundsException. Por eso verificamos contra el modelo y convertimos
        // viewRow -> modelRow de forma segura.
        if (table == null || table.getModel() == null) return -1;

        // Si no hay columnas, no hay checkbox que chequear.
        if (table.getColumnCount() <= 0 || table.getModel().getColumnCount() <= 0) return -1;

        final TableModel model = table.getModel();
        final int viewRowCount = table.getRowCount();

        for (int viewRow = 0; viewRow < viewRowCount; viewRow++) {
            int modelRow;
            try {
                modelRow = table.convertRowIndexToModel(viewRow);
            } catch (Exception ex) {
                // Sin sorter o estado transitorio
                modelRow = viewRow;
            }

            if (modelRow < 0 || modelRow >= model.getRowCount()) {
                continue;
            }

            try {
                Object val = model.getValueAt(modelRow, 0);
                if (Boolean.TRUE.equals(val)) {
                    return viewRow; // devolvemos índice en VISTA
                }
            } catch (IndexOutOfBoundsException ex) {
                // Estado transitorio entre actualización de modelo y vista
                continue;
            }
        }
        return -1;
    }

    public boolean isTableNotEmpty(JTable table) {
        return table != null && table.getRowCount() > 0;
    }

    public void mouseTooltipText(JTable table, List<Integer> indicesColumnasConTooltip) {
        tooltipValorEnColumnas(table, indicesColumnasConTooltip);
    }

    /**
     * Versión estática para reutilizar desde cualquier formulario.
     * Los índices son los de la VISTA (los que ves en la JTable).
     */
    public static void tooltipValorEnColumnas(JTable table, List<Integer> indicesColumnasConTooltip) {
        if (table == null || indicesColumnasConTooltip == null || indicesColumnasConTooltip.isEmpty()) return;

        table.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                int column = table.columnAtPoint(e.getPoint());

                if (row == -1 || column == -1) {
                    table.setToolTipText(null);
                    return;
                }

                if (indicesColumnasConTooltip.contains(column)) {
                    Object value = table.getValueAt(row, column);
                    table.setToolTipText(value != null ? value.toString() : null);
                } else {
                    table.setToolTipText(null);
                }
            }
        });
    }

    /**
     * Tooltips fijos por columna (descriptivos). Ideal para explicar columnas.
     *
     * @param tooltipsPorColumnaModel Key: índice de columna en MODELO, Value: texto tooltip
     */
    public static void aplicarTooltipsPorColumna(JTable table, Map<Integer, String> tooltipsPorColumnaModel) {
        if (table == null || tooltipsPorColumnaModel == null || tooltipsPorColumnaModel.isEmpty()) return;

        table.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                int viewCol = table.columnAtPoint(e.getPoint());
                if (row == -1 || viewCol == -1) {
                    table.setToolTipText(null);
                    return;
                }
                int modelCol = table.convertColumnIndexToModel(viewCol);
                String tip = tooltipsPorColumnaModel.get(modelCol);
                table.setToolTipText(tip);
            }
        });
    }

    /**
     * Agrega DocumentListener al campo de búsqueda y aplica filtro + resaltado en tiempo real.
     *
     * Importante: columnasObjetivo debe referenciar columnas de la VISTA (JTable).
     */
    public static void aplicarFiltroYResaltado(JTable table, JTextField txtBusqueda, List<Integer> columnasObjetivo) {
        if (table == null || txtBusqueda == null || columnasObjetivo == null) return;

        txtBusqueda.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                refrescarFiltro(table, txtBusqueda, columnasObjetivo);
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                refrescarFiltro(table, txtBusqueda, columnasObjetivo);
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                refrescarFiltro(table, txtBusqueda, columnasObjetivo);
            }
        });
    }

    /**
     * Reaplica el filtro/resaltado usando el texto actual del JTextField.
     * Útil para cuando se recarga el modelo de la tabla y se desea mantener la búsqueda vigente.
     */
    
    /**
     * Variante PRO: aplica filtro por texto (con resaltado) y además un filtro extra (por ejemplo, estado).
     * El filtro final es AND(texto, extra) cuando ambos están presentes.
     */
    public static void aplicarFiltroYResaltadoCombinado(JTable table, JTextField txtBusqueda, List<Integer> columnasObjetivo, Supplier<RowFilter<Object, Object>> filtroExtraSupplier) {
        if (table == null || txtBusqueda == null || columnasObjetivo == null) return;

        txtBusqueda.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                refrescarFiltroCombinado(table, txtBusqueda, columnasObjetivo, filtroExtraSupplier != null ? filtroExtraSupplier.get() : null);
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                refrescarFiltroCombinado(table, txtBusqueda, columnasObjetivo, filtroExtraSupplier != null ? filtroExtraSupplier.get() : null);
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                refrescarFiltroCombinado(table, txtBusqueda, columnasObjetivo, filtroExtraSupplier != null ? filtroExtraSupplier.get() : null);
            }
        });
    }

    /**
     * Reaplica el filtro combinado (texto + extra) usando el texto actual del JTextField.
     */
    public static void refrescarFiltroCombinado(JTable table, JTextField txtBusqueda, List<Integer> columnasObjetivo, RowFilter<Object, Object> filtroExtra) {
        if (table == null || txtBusqueda == null) return;
        filtrarYResaltarCombinado(table, txtBusqueda.getText(), columnasObjetivo, filtroExtra);
    }

    private static void filtrarYResaltarCombinado(JTable table, String query, List<Integer> columnasObjetivoVista, RowFilter<Object, Object> filtroExtra) {
        if (table == null || table.getModel() == null) return;

        // Reutilizar sorter si ya existe; si no, crear uno
        TableRowSorter<TableModel> sorter;
        if (table.getRowSorter() instanceof TableRowSorter) {
            //noinspection unchecked
            sorter = (TableRowSorter<TableModel>) table.getRowSorter();
            sorter.setModel(table.getModel());
        } else {
            sorter = new TableRowSorter<>(table.getModel());
            table.setRowSorter(sorter);
        }

        String q = query != null ? query.trim() : "";

        // Convertir columnas objetivo (vista) a columnas en modelo (RowFilter trabaja sobre modelo)
        int[] colsModel = toModelColumns(table, columnasObjetivoVista);

        RowFilter<Object, Object> filtroTexto = null;
        if (!q.isEmpty()) {
            filtroTexto = RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(q), colsModel);
        }

        RowFilter<Object, Object> filtroFinal;
        if (filtroTexto != null && filtroExtra != null) {
            List<RowFilter<Object, Object>> filtros = new ArrayList<>();
            filtros.add(filtroTexto);
            filtros.add(filtroExtra);
            filtroFinal = RowFilter.andFilter(filtros);
        } else if (filtroTexto != null) {
            filtroFinal = filtroTexto;
        } else {
            filtroFinal = filtroExtra; // puede ser null (sin filtros)
        }

        sorter.setRowFilter(filtroFinal);

        // Resaltado sólo si hay texto (para evitar HTML/renderer innecesario)
        if (filtroTexto != null) {
            table.setDefaultRenderer(Object.class, new ResaltarCoincidenciasRenderer(q, columnasObjetivoVista));
        } else {
            table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer());
        }
    }

public static void refrescarFiltro(JTable table, JTextField txtBusqueda, List<Integer> columnasObjetivo) {
        if (table == null || txtBusqueda == null) return;
        filtrarYResaltar(table, txtBusqueda.getText(), columnasObjetivo);
    }

    private static void filtrarYResaltar(JTable table, String query, List<Integer> columnasObjetivoVista) {
        if (table == null || table.getModel() == null) return;

        // Reutilizar sorter si ya existe; si no, crear uno
        TableRowSorter<TableModel> sorter;
        if (table.getRowSorter() instanceof TableRowSorter) {
            //noinspection unchecked
            sorter = (TableRowSorter<TableModel>) table.getRowSorter();
            sorter.setModel(table.getModel());
        } else {
            sorter = new TableRowSorter<>(table.getModel());
            table.setRowSorter(sorter);
        }

        String q = query != null ? query.trim() : "";

        if (q.isEmpty()) {
            sorter.setRowFilter(null);
            // Restablecer renderer para no forzar HTML en celdas
            table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer());
            return;
        }

        // Convertir columnas objetivo (vista) a columnas en modelo (RowFilter trabaja sobre modelo)
        int[] colsModel = toModelColumns(table, columnasObjetivoVista);

        RowFilter<Object, Object> filtro = RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(q), colsModel);
        sorter.setRowFilter(filtro);

        // Establecer renderizador para resaltar coincidencias (en columnas de vista)
        table.setDefaultRenderer(Object.class, new ResaltarCoincidenciasRenderer(q, columnasObjetivoVista));
    }

    private static int[] toModelColumns(JTable table, List<Integer> viewCols) {
        List<Integer> result = new ArrayList<>();
        for (Integer viewCol : viewCols) {
            if (viewCol == null) continue;
            if (viewCol >= 0 && viewCol < table.getColumnCount()) {
                result.add(table.convertColumnIndexToModel(viewCol));
            }
        }
        return result.stream().mapToInt(i -> i).toArray();
    }

    private static class ResaltarCoincidenciasRenderer extends DefaultTableCellRenderer {
        private final String query;
        private final List<Integer> columnasObjetivoVista;

        public ResaltarCoincidenciasRenderer(String query, List<Integer> columnasObjetivoVista) {
            this.query = query;
            this.columnasObjetivoVista = columnasObjetivoVista;
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            if (columnasObjetivoVista != null
                    && columnasObjetivoVista.contains(column)
                    && value != null
                    && query != null
                    && !query.isEmpty()) {

                String cellValue = value.toString();
                String lowerCellValue = cellValue.toLowerCase();
                String lowerQuery = query.toLowerCase();

                // Resaltar si contiene el texto (no sólo al inicio) para mejor UX
                int idx = lowerCellValue.indexOf(lowerQuery);
                if (idx >= 0) {
                    String before = cellValue.substring(0, idx);
                    String match = cellValue.substring(idx, idx + query.length());
                    String after = cellValue.substring(idx + query.length());
                    String highlightedText = "<html>" + escapeHtml(before)
                            + "<span style='color:#FFA500; font-weight:bold;'>" + escapeHtml(match) + "</span>"
                            + escapeHtml(after) + "</html>";
                    setText(highlightedText);
                } else {
                    setText(cellValue);
                }
            } else {
                setText(value != null ? value.toString() : "");
            }

            return c;
        }

        private String escapeHtml(String s) {
            if (s == null) return "";
            return s.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;");
        }
    }
}