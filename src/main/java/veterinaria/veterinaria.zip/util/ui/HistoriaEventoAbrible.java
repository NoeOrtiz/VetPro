package veterinaria.util.ui;

/**
 * Contrato simple para formularios que pueden abrir un registro puntual
 * a partir de un ID (por ejemplo: visita, laboratorio, hospitalización, etc.).
 */
public interface HistoriaEventoAbrible {
    void abrirDetallePorId(Integer refId);
}
