package veterinaria.servicio;

@Deprecated
public class TurnoService extends PeluqueriaService {
    // Clase puente por compatibilidad histórica.
}
