package veterinaria.servicio;

import java.util.Date;
import java.util.List;

import veterinaria.entidad.Auditoria;
import veterinaria.entidad.Usuario;
import veterinaria.persistencia.AuditoriaDAO;
import veterinaria.util.SesionUsuario;

/**
 * Servicio central de auditoría (DB).
 *
 * Reglas:
 *  - Solo audita usuarios logeados (SesionUsuario.usuario != null)
 *  - Retención/purga: DESACTIVADA (a pedido). Si se requiere retención,
 *    debe implementarse como tarea administrativa fuera del flujo normal.
 *  - NO registra IP (sistema local/offline)
 *
 * Nota operativa:
 *  - La auditoría NO debe bloquear el flujo principal (login/ABM). Si la tabla no está
 *    correctamente migrada o hay un error DB, se registra en consola y se continúa.
 */
public class AuditoriaService {

    public static final String RESULT_OK = "OK";
    public static final String RESULT_ERROR = "ERROR";

    private final AuditoriaDAO auditoriaDAO = new AuditoriaDAO();

    public void registrar(String accion, String entidad, Long entidadId, String modulo,
                          String descripcion, String resultado,
                          String datosAntes, String datosDespues, String errorDetalle) {

        Usuario usuario = SesionUsuario.getInstancia().getUsuario();
        if (usuario == null) {
            // Regla: solo usuarios logeados
            return;
        }

        try {
            Auditoria a = new Auditoria();
            a.setFechaHora(new Date());
            a.setUsuario(usuario);
            a.setAccion(accion);
            a.setEntidad(entidad);
            a.setEntidadId(entidadId);
            a.setModulo(modulo);
            a.setDescripcion(descripcion);
            a.setResultado(resultado != null ? resultado : RESULT_OK);
            a.setDatosAntes(datosAntes);
            a.setDatosDespues(datosDespues);
            a.setErrorDetalle(errorDetalle);

            auditoriaDAO.guardar(a);
        } catch (Exception ex) {
            // No bloquear operaciones core por auditoría
            System.err.println("[AUDITORIA] No se pudo registrar evento: " + ex.getMessage());
        }
    }

    /**
     * Registra un evento SIN requerir usuario logeado.
     *
     * Uso típico: intentos de login fallidos (no hay sesión aún).
     *
     * Importante:
     *  - usuario_id queda NULL.
     *  - Si la tabla auditoria no está migrada, NO debe romper el flujo principal.
     */
    public void registrarSinSesion(String accion, String entidad, Long entidadId, String modulo,
                                   String descripcion, String resultado,
                                   String datosAntes, String datosDespues, String errorDetalle) {
        try {
            Auditoria a = new Auditoria();
            a.setFechaHora(new Date());
            a.setUsuario(null);
            a.setAccion(accion);
            a.setEntidad(entidad);
            a.setEntidadId(entidadId);
            a.setModulo(modulo);
            a.setDescripcion(descripcion);
            a.setResultado(resultado != null ? resultado : RESULT_OK);
            a.setDatosAntes(datosAntes);
            a.setDatosDespues(datosDespues);
            a.setErrorDetalle(errorDetalle);

            auditoriaDAO.guardar(a);
        } catch (Exception ex) {
            System.err.println("[AUDITORIA] No se pudo registrar evento (sin sesión): " + ex.getMessage());
        }
    }

    public List<Auditoria> buscar(Date desde, Date hasta, Integer usuarioId, String accion, String entidad) {
        return auditoriaDAO.buscar(desde, hasta, usuarioId, accion, entidad);
    }

    public Auditoria obtenerPorId(Long id) {
        return auditoriaDAO.obtenerPorId(id);
    }

    // NOTA: se eliminó el helper de purga automática para evitar deletes masivos
    // dentro del flujo principal (especialmente login / acciones UI).
}
