package veterinaria.servicio;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import veterinaria.entidad.Persona;
import veterinaria.entidad.Rol;
import veterinaria.entidad.Usuario;
import veterinaria.entidad.UsuarioRol;
import veterinaria.persistencia.JPAUtil;
import veterinaria.persistencia.RecuperacionClaveTokenDAO;
import veterinaria.persistencia.UsuarioRolDAO;
import veterinaria.util.PasswordSecurityUtil;
import veterinaria.util.SesionUsuario;

/**
 * Servicio centralizado para autenticación y recuperación de credenciales.
 *
 * Evita mezclar reglas de login/recuperación entre DAO, controlador y UI.
 */
public class AutenticacionService {

    private final AuditoriaService auditoriaService = new AuditoriaService();
    private final RecuperacionClaveTokenDAO recuperacionClaveTokenDAO = new RecuperacionClaveTokenDAO();

    public boolean validarLogin(String nombreUsuario, String contrasena) {
        EntityManager em = JPAUtil.getEntityManager();
        UsuarioRolDAO rolDAO = new UsuarioRolDAO();
        try {
            Long totalUsuarios = em.createQuery("SELECT COUNT(u) FROM Usuario u", Long.class)
                    .getSingleResult();

            if (totalUsuarios != null && totalUsuarios == 0L) {
                return validarBootstrapInicial(em, rolDAO, nombreUsuario, contrasena);
            }

            Usuario usuario = buscarUsuarioParaLogin(em, nombreUsuario);
            if (usuario == null) {
                registrarLoginFallido(null, nombreUsuario, "Usuario no encontrado");
                return false;
            }

            if (!PasswordSecurityUtil.matches(contrasena, usuario.getContrasena())) {
                registrarLoginFallido(Long.valueOf(usuario.getIdUsuario()), nombreUsuario, "Credenciales inválidas");
                return false;
            }

            migrarHashSiCorresponde(em, usuario, contrasena);
            asegurarRol(usuario, rolDAO);

            SesionUsuario.getInstancia().iniciarSesion(usuario);
            auditoriaService.registrar(
                    "LOGIN",
                    "Usuario",
                    Long.valueOf(usuario.getIdUsuario()),
                    "FormLogin",
                    "Inicio de sesión",
                    AuditoriaService.RESULT_OK,
                    null,
                    null,
                    null
            );
            return true;
        } catch (Exception ex) {
            registrarLoginFallido(null, nombreUsuario, ex.getMessage());
            return false;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public boolean actualizarContrasenaPorRecuperacion(String nombreUsuario, String emailUsuario, String dni, String nuevaContrasena) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            Usuario usuario = em.createQuery(
                    "SELECT u FROM Usuario u "
                    + "LEFT JOIN u.persona p "
                    + "WHERE lower(trim(u.nombreUsuario)) = :nombreUsuario "
                    + "AND lower(trim(u.email)) = :emailUsuario "
                    + "AND trim(p.dni) = :dni",
                    Usuario.class)
                    .setParameter("nombreUsuario", nombreUsuario.trim().toLowerCase())
                    .setParameter("emailUsuario", emailUsuario.trim().toLowerCase())
                    .setParameter("dni", dni.trim())
                    .getResultStream()
                    .findFirst()
                    .orElse(null);

            if (usuario == null) {
                auditoriaService.registrarSinSesion(
                        "PASSWORD_RESET_FAIL",
                        "Usuario",
                        null,
                        "RecuperarContrasenaDialog",
                        "Intento de recuperación de contraseña sin coincidencia. usuario=" + nombreUsuario,
                        AuditoriaService.RESULT_ERROR,
                        null,
                        null,
                        "Usuario/e-mail/DNI no coinciden"
                );
                return false;
            }

            em.getTransaction().begin();
            usuario.setContrasena(PasswordSecurityUtil.normalizeForPersist(nuevaContrasena));
            em.merge(usuario);
            em.getTransaction().commit();

            auditoriaService.registrarSinSesion(
                    "PASSWORD_RESET",
                    "Usuario",
                    Long.valueOf(usuario.getIdUsuario()),
                    "RecuperarContrasenaDialog",
                    "Contraseña restablecida para el usuario " + usuario.getNombreUsuario(),
                    AuditoriaService.RESULT_OK,
                    null,
                    null,
                    null
            );
            return true;
        } catch (Exception ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            auditoriaService.registrarSinSesion(
                    "PASSWORD_RESET_ERROR",
                    "Usuario",
                    null,
                    "RecuperarContrasenaDialog",
                    "Error al restablecer contraseña. usuario=" + nombreUsuario,
                    AuditoriaService.RESULT_ERROR,
                    null,
                    null,
                    ex.getMessage()
            );
            return false;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public String generarCodigoRecuperacion(String nombreUsuario, String email, String dni) {
        return recuperacionClaveTokenDAO.generarCodigoRecuperacion(nombreUsuario, email, dni, 10);
    }

    public boolean restablecerConCodigo(String nombreUsuario, String email, String dni, String codigo, String nuevaContrasena) {
        return recuperacionClaveTokenDAO.restablecerConCodigo(nombreUsuario, email, dni, codigo, nuevaContrasena);
    }

    private boolean validarBootstrapInicial(EntityManager em, UsuarioRolDAO rolDAO, String nombreUsuario, String contrasena) {
        if (!"admin".equalsIgnoreCase(nombreUsuario) || !"admin".equals(contrasena)) {
            registrarLoginFallido(null, nombreUsuario, "Credenciales inválidas");
            return false;
        }

        Usuario admin = bootstrapCrearPrimerAdmin(em);
        asegurarRol(admin, rolDAO);
        SesionUsuario.getInstancia().iniciarSesion(admin);
        auditoriaService.registrar(
                "LOGIN",
                "Usuario",
                Long.valueOf(admin.getIdUsuario()),
                "FormLogin",
                "Inicio de sesión (bootstrap)",
                AuditoriaService.RESULT_OK,
                null,
                null,
                null
        );
        return true;
    }

    private Usuario buscarUsuarioParaLogin(EntityManager em, String nombreUsuario) {
        try {
            return em.createQuery(
                    "SELECT u FROM Usuario u "
                    + "LEFT JOIN FETCH u.rol "
                    + "LEFT JOIN FETCH u.persona "
                    + "WHERE lower(trim(u.nombreUsuario)) = :nombreUsuario",
                    Usuario.class)
                    .setParameter("nombreUsuario", nombreUsuario == null ? "" : nombreUsuario.trim().toLowerCase())
                    .setMaxResults(1)
                    .getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }

    private void migrarHashSiCorresponde(EntityManager em, Usuario usuario, String rawPassword) {
        if (usuario == null || usuario.getIdUsuario() == null || !PasswordSecurityUtil.needsMigration(usuario.getContrasena())) {
            return;
        }

        try {
            em.getTransaction().begin();
            Usuario managed = em.find(Usuario.class, usuario.getIdUsuario());
            if (managed != null) {
                String nuevoHash = PasswordSecurityUtil.normalizeForPersist(rawPassword);
                managed.setContrasena(nuevoHash);
                em.merge(managed);
                usuario.setContrasena(nuevoHash);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
        }
    }

    private void asegurarRol(Usuario usuario, UsuarioRolDAO rolDAO) {
        if (usuario != null && usuario.getRol() == null && usuario.getIdUsuario() != null) {
            Rol rol = rolDAO.obtenerRol(usuario.getIdUsuario());
            usuario.setRol(rol);
        }
    }

    private void registrarLoginFallido(Long usuarioId, String nombreUsuario, String detalle) {
        auditoriaService.registrarSinSesion(
                "LOGIN_FAIL",
                "Usuario",
                usuarioId,
                "FormLogin",
                "Intento de inicio de sesión fallido. usuario=" + nombreUsuario,
                AuditoriaService.RESULT_ERROR,
                null,
                null,
                detalle
        );
    }

    private Usuario bootstrapCrearPrimerAdmin(EntityManager em) {
        em.getTransaction().begin();
        try {
            Rol rolAdmin = em.createQuery("SELECT r FROM Rol r WHERE r.nombreRol = :nombre", Rol.class)
                    .setParameter("nombre", "Administrador")
                    .setMaxResults(1)
                    .getSingleResult();

            Persona persona = new Persona();
            persona.setNombre("Administrador");
            persona.setApellido("Inicial");
            persona.setDireccion("");
            persona.setTelefono("");
            persona.setDni("0");
            em.persist(persona);

            Usuario usuario = new Usuario();
            usuario.setPersona(persona);
            usuario.setEmail("admin@local");
            usuario.setNombreUsuario("admin");
            usuario.setContrasena(PasswordSecurityUtil.normalizeForPersist("admin"));
            usuario.setRol(rolAdmin);
            em.persist(usuario);

            UsuarioRol ur = new UsuarioRol();
            ur.setUsuario(usuario);
            ur.setRol(rolAdmin);
            em.persist(ur);

            em.getTransaction().commit();
            return usuario;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        }
    }
}
