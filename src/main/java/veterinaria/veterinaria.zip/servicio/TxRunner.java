package veterinaria.servicio;

import javax.persistence.EntityManager;
import veterinaria.persistencia.JPAUtil;

/**
 * Ejecuta casos de uso dentro de una ÚNICA transacción y con un ÚNICO EntityManager.
 *
 * Si algo falla: rollback de TODA la operación.
 */
public class TxRunner {

    @FunctionalInterface
    public interface TxWork<T> {
        T apply(EntityManager em) throws Exception;
    }

    public <T> T runInTx(TxWork<T> work) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            T result = work.apply(em);
            em.getTransaction().commit();
            return result;
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw (e instanceof RuntimeException) ? (RuntimeException) e : new RuntimeException(e);
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    /**
     * Variante: ejecuta en una única transacción y, si el COMMIT fue exitoso,
     * ejecuta un hook post-commit (ideal para auditoría).
     *
     * Nota: el hook se ejecuta FUERA de la transacción principal.
     */
    public <T> T runInTx(TxWork<T> work, Runnable afterCommit) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            T result = work.apply(em);
            em.getTransaction().commit();
            if (afterCommit != null) {
                try {
                    afterCommit.run();
                } catch (Exception hookEx) {
                    // Nunca bloquear el flujo principal por acciones post-commit.
                    System.err.println("[TX] afterCommit falló: " + hookEx.getMessage());
                }
            }
            return result;
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw (e instanceof RuntimeException) ? (RuntimeException) e : new RuntimeException(e);
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void runInTxVoid(TxWork<Void> work) {
        runInTx(work);
    }
}
