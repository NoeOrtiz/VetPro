package veterinaria.servicio;

import javax.persistence.EntityManager;

import veterinaria.entidad.Persona;
import veterinaria.entidad.Rol;
import veterinaria.entidad.Usuario;
import veterinaria.entidad.UsuarioRol;
import veterinaria.util.JsonUtil;
import veterinaria.util.PasswordSecurityUtil;

/**
 * Caso de uso: gestión atómica (1 TX) de Persona + Usuario + UsuarioRol.
 */
public class UsuarioService {

    private final TxRunner txRunner = new TxRunner();
    private final PersonaService personaService = new PersonaService();
    private final AuditoriaService auditoriaService = new AuditoriaService();

    public boolean crearUsuario(Persona persona, Usuario usuario) {
        final Long[] idOut = new Long[1];
        final String[] datosDespues = new String[1];
        boolean ok = txRunner.runInTx(em -> {
            // 1) Persona
            Persona personaManaged = personaService.persistOrAttach(em, persona);

            // 2) Rol (FK idRol en Usuario)
            Rol rolManaged = attachRol(em, usuario.getRol());

            // 3) Usuario
            usuario.setPersona(personaManaged);
            usuario.setRol(rolManaged);
            usuario.setContrasena(PasswordSecurityUtil.normalizeForPersist(usuario.getContrasena()));
            em.persist(usuario);

            // asegurar ID antes del commit
            em.flush();
            idOut[0] = (usuario.getIdUsuario() != null ? Long.valueOf(usuario.getIdUsuario()) : null);
            datosDespues[0] = JsonUtil.safeToJson(usuario);

            // 4) Tabla usuariorol (si se usa)
            em.persist(new UsuarioRol(usuario, rolManaged));

            return true;
        }, () -> {
            auditoriaService.registrar(
                    "CREATE",
                    "Usuario",
                    idOut[0],
                    "UsuarioService",
                    "Alta de usuario: " + (usuario != null ? usuario.getNombreUsuario() : ""),
                    AuditoriaService.RESULT_OK,
                    null,
                    datosDespues[0],
                    null
            );
        });
        return ok;
    }

    public boolean actualizarUsuario(Persona persona, Usuario usuario, Rol nuevoRol) {
        final Long id = (usuario != null && usuario.getIdUsuario() != null) ? Long.valueOf(usuario.getIdUsuario()) : null;
        final String[] antes = new String[1];
        final String[] despues = new String[1];
        boolean ok = txRunner.runInTx(em -> {
            // snapshot antes
            if (usuario != null && usuario.getIdUsuario() != null) {
                Usuario prev = em.find(Usuario.class, usuario.getIdUsuario());
                if (prev != null) antes[0] = JsonUtil.safeToJson(prev);
            }

            // 1) Persona
            Persona personaManaged = personaService.merge(em, persona);

            // 2) Usuario
            Rol rolManaged = attachRol(em, nuevoRol);
            usuario.setPersona(personaManaged);
            usuario.setRol(rolManaged);
            if (usuario.getContrasena() != null && !usuario.getContrasena().trim().isEmpty()) {
                usuario.setContrasena(PasswordSecurityUtil.normalizeForPersist(usuario.getContrasena()));
            }
            Usuario usuarioManaged = em.merge(usuario);

            em.flush();
            despues[0] = JsonUtil.safeToJson(usuarioManaged);

            // 3) Actualizar usuariorol: dejamos 1 rol por usuario
            em.createQuery("DELETE FROM UsuarioRol ur WHERE ur.usuario.idUsuario = :id")
                    .setParameter("id", usuarioManaged.getIdUsuario())
                    .executeUpdate();
            em.persist(new UsuarioRol(usuarioManaged, rolManaged));

            return true;
        }, () -> {
            auditoriaService.registrar(
                    "UPDATE",
                    "Usuario",
                    id,
                    "UsuarioService",
                    "Actualización de usuario: " + (usuario != null ? usuario.getNombreUsuario() : ""),
                    AuditoriaService.RESULT_OK,
                    antes[0],
                    despues[0],
                    null
            );
        });
        return ok;
    }

    public boolean eliminarUsuario(Persona persona, Usuario usuario, Rol rol) {
        final Long id = (usuario != null && usuario.getIdUsuario() != null) ? Long.valueOf(usuario.getIdUsuario()) : null;
        final String[] antes = new String[1];
        boolean ok = txRunner.runInTx(em -> {
            Integer idUsuario = usuario != null ? usuario.getIdUsuario() : null;
            Integer idPersona = persona != null ? persona.getIdPersona() : null;

            if (idUsuario == null) {
                throw new IllegalArgumentException("El idUsuario no puede ser null");
            }

            // 1) Eliminar relación usuario-rol (borramos todas las filas de ese usuario)
            em.createQuery("DELETE FROM UsuarioRol ur WHERE ur.usuario.idUsuario = :id")
                    .setParameter("id", idUsuario)
                    .executeUpdate();

            // 1.1) Desvincular auditoría para NO romper integridad referencial.
            // Regla de negocio: la auditoría debe preservarse, pero el usuario puede eliminarse.
            // Como la FK auditoria.usuario_id apunta a usuario.idUsuario, primero ponemos NULL.
            // (La tabla auditoria ya soporta usuario_id NULL: ver AuditoriaService.registrarSinSesion)
            em.createQuery("UPDATE Auditoria a SET a.usuario = NULL WHERE a.usuario.idUsuario = :id")
                    .setParameter("id", idUsuario)
                    .executeUpdate();

            // 2) Eliminar usuario
            Usuario usuarioManaged = em.find(Usuario.class, idUsuario);
            if (usuarioManaged != null) {
                antes[0] = JsonUtil.safeToJson(usuarioManaged);
                // si no me pasaron la persona, la deduzco del usuario
                if (idPersona == null && usuarioManaged.getPersona() != null) {
                    idPersona = usuarioManaged.getPersona().getIdPersona();
                }
                em.remove(usuarioManaged);
            }

            // 3) Eliminar persona solo si no está referenciada por otras entidades
            personaService.deleteIfUnused(em, idPersona);

            return true;
        }, () -> {
            auditoriaService.registrar(
                    "DELETE",
                    "Usuario",
                    id,
                    "UsuarioService",
                    "Baja de usuario: " + (usuario != null ? usuario.getNombreUsuario() : ""),
                    AuditoriaService.RESULT_OK,
                    antes[0],
                    null,
                    null
            );
        });
        return ok;
    }

    private Rol attachRol(EntityManager em, Rol rol) {
        if (rol == null || rol.getIdRol() == null) {
            throw new IllegalArgumentException("El rol del usuario es requerido (idRol)");
        }
        Rol rolManaged = em.find(Rol.class, rol.getIdRol());
        if (rolManaged == null) {
            throw new IllegalArgumentException("El rol con id " + rol.getIdRol() + " no existe");
        }
        return rolManaged;
    }
}
