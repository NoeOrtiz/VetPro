package veterinaria.servicio;


public class RecuperacionClaveService {

    private final AutenticacionService autenticacionService = new AutenticacionService();

    public String generarCodigoRecuperacion(String nombreUsuario, String email, String dni) {
        return autenticacionService.generarCodigoRecuperacion(nombreUsuario, email, dni);
    }

    public boolean restablecerConCodigo(String nombreUsuario, String email, String dni, String codigo, String nuevaContrasena) {
        return autenticacionService.restablecerConCodigo(nombreUsuario, email, dni, codigo, nuevaContrasena);
    }
}
