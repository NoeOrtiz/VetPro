package veterinaria.servicio;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import veterinaria.entidad.CajaMovimiento;
import veterinaria.entidad.CajaMovimiento.TipoMovimiento;
import veterinaria.entidad.Usuario;

/**
 * Servicios transaccionales para CajaMovimiento.
 *
 * Mantiene el patrón:
 *  - UNA sola transacción por operación completa
 *  - Un único EntityManager por caso de uso
 */
public class CajaService {

    private final TxRunner tx = new TxRunner();

    /**
     * Normaliza una fecha a solo día (00:00:00.000) para evitar problemas de igualdad
     * cuando se usa @Temporal(DATE).
     */
    private static Date onlyDate(Date d) {
        if (d == null) return null;
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.setTime(d);
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    private CajaMovimiento findLast(EntityManager em, CajaMovimiento.TipoMovimiento tipo) {
        TypedQuery<CajaMovimiento> q = em.createQuery(
                "SELECT c FROM CajaMovimiento c WHERE c.tipoMovimiento = :tipo AND c.eliminado = false " +
                "ORDER BY c.fecha DESC, c.idMovimiento DESC",
                CajaMovimiento.class
        );
        q.setParameter("tipo", tipo);
        q.setMaxResults(1);
        try {
            return q.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }

    private BigDecimal sumByDateAndTipo(EntityManager em, Date fecha, CajaMovimiento.TipoMovimiento tipo) {
        TypedQuery<BigDecimal> q = em.createQuery(
                "SELECT COALESCE(SUM(c.monto), 0) FROM CajaMovimiento c " +
                "WHERE c.tipoMovimiento = :tipo AND c.fecha = :fecha AND c.eliminado = false",
                BigDecimal.class
        );
        q.setParameter("tipo", tipo);
        q.setParameter("fecha", onlyDate(fecha));
        BigDecimal r = q.getSingleResult();
        return r == null ? BigDecimal.ZERO : r;
    }

    private CajaMovimiento findAperturaByDate(EntityManager em, Date fecha) {
        TypedQuery<CajaMovimiento> q = em.createQuery(
                "SELECT c FROM CajaMovimiento c WHERE c.tipoMovimiento = :tipo AND c.fecha = :fecha AND c.eliminado = false",
                CajaMovimiento.class
        );
        q.setParameter("tipo", CajaMovimiento.TipoMovimiento.APERTURA);
        q.setParameter("fecha", onlyDate(fecha));
        q.setMaxResults(1);
        try {
            return q.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }

    private boolean isCajaAbiertaSinCierre(EntityManager em) {
        CajaMovimiento lastApertura = findLast(em, CajaMovimiento.TipoMovimiento.APERTURA);
        if (lastApertura == null) return false;

        CajaMovimiento lastCierre = findLast(em, CajaMovimiento.TipoMovimiento.CIERRE);
        if (lastCierre == null) return true;

        // Si la última apertura es posterior al último cierre, hay caja abierta.
        return lastApertura.getFecha().after(lastCierre.getFecha());
    }

    private Date getFechaCajaPendiente(EntityManager em) {
        CajaMovimiento lastApertura = findLast(em, CajaMovimiento.TipoMovimiento.APERTURA);
        if (lastApertura == null) return null;
        CajaMovimiento lastCierre = findLast(em, CajaMovimiento.TipoMovimiento.CIERRE);
        if (lastCierre == null) return onlyDate(lastApertura.getFecha());
        if (lastApertura.getFecha().after(lastCierre.getFecha())) {
            return onlyDate(lastApertura.getFecha());
        }
        return null;
    }

    public boolean registrarMovimiento(CajaMovimiento movimiento) {
        return tx.runInTx(em -> {
            CajaMovimiento m = movimiento;

            // Asegurar referencias MANAGED (evita persist de entidades detached)
            if (m.getUsuario() != null && m.getUsuario().getIdUsuario() != null) {
                Usuario usuarioMG = em.find(Usuario.class, m.getUsuario().getIdUsuario());
                m.setUsuario(usuarioMG);
            }

            em.persist(m);
            return true;
        });
    }

    public boolean modificarMovimiento(CajaMovimiento movimiento) {
        return tx.runInTx(em -> {
            CajaMovimiento existente = em.find(CajaMovimiento.class, movimiento.getIdMovimiento());
            if (existente == null) {
                return false;
            }
            existente.setMonto(movimiento.getMonto());
            existente.setTipoMovimiento(movimiento.getTipoMovimiento());
            existente.setFecha(movimiento.getFecha());
            existente.setDescripcion(movimiento.getDescripcion());
            existente.setEliminado(movimiento.isEliminado());

            if (movimiento.getUsuario() != null && movimiento.getUsuario().getIdUsuario() != null) {
                Usuario usuarioMG = em.find(Usuario.class, movimiento.getUsuario().getIdUsuario());
                existente.setUsuario(usuarioMG);
            } else {
                existente.setUsuario(null);
            }

            em.merge(existente);
            return true;
        });
    }

    public boolean existeMovimientoEnFecha(Date fecha, TipoMovimiento tipo) {
        return tx.runInTx(em -> existeMovimientoEnFecha(em, onlyDate(fecha), tipo));
    }

    private boolean existeMovimientoEnFecha(EntityManager em, Date fecha, TipoMovimiento tipo) {
        TypedQuery<Long> query = em.createQuery(
                "SELECT COUNT(c) FROM CajaMovimiento c " +
                "WHERE c.tipoMovimiento = :tipo AND c.fecha = :fecha AND c.eliminado = false",
                Long.class
        );
        query.setParameter("tipo", tipo);
        query.setParameter("fecha", onlyDate(fecha));
        return query.getSingleResult() > 0;
    }

    /**
     * Registra apertura de caja de forma atómica: valida y persiste en UNA TX.
     */
    public boolean registrarApertura(BigDecimal montoInicial, Usuario usuario, Date fecha) {
        return tx.runInTx(em -> {
            Date f = onlyDate(fecha);

            // Regla: no se puede abrir una nueva caja si existe una caja abierta sin cierre (aunque sea de otro día).
            if (isCajaAbiertaSinCierre(em)) {
                Date pendiente = getFechaCajaPendiente(em);
                throw new IllegalStateException(
                        "Existe una caja ABIERTA sin cierre (" + pendiente + "). Debe cerrar la caja antes de abrir nuevamente."
                );
            }

            if (existeMovimientoEnFecha(em, f, TipoMovimiento.APERTURA)) {
                throw new IllegalStateException("La caja ya fue abierta en la fecha indicada.");
            }
            if (existeMovimientoEnFecha(em, f, TipoMovimiento.CIERRE)) {
                throw new IllegalStateException("La caja ya fue cerrada en la fecha indicada.");
            }

            CajaMovimiento apertura = new CajaMovimiento();
            apertura.setMonto(montoInicial);
            apertura.setTipoMovimiento(TipoMovimiento.APERTURA);
            apertura.setFecha(f);
            apertura.setDescripcion("Apertura de caja");

            if (usuario != null && usuario.getIdUsuario() != null) {
                Usuario usuarioMG = em.find(Usuario.class, usuario.getIdUsuario());
                apertura.setUsuario(usuarioMG);
            } else {
                apertura.setUsuario(null);
            }

            em.persist(apertura);
            return true;
        });
    }

    /**
     * Registra cierre de caja de forma atómica: valida y persiste en UNA TX.
     */
    public boolean registrarCierre(BigDecimal montoFinal, Usuario usuario, Date fecha) {
        return tx.runInTx(em -> {
            Date f = onlyDate(fecha);

            if (existeMovimientoEnFecha(em, f, TipoMovimiento.CIERRE)) {
                throw new IllegalStateException("La caja ya fue cerrada en la fecha indicada.");
            }

            CajaMovimiento apertura = findAperturaByDate(em, f);
            if (apertura == null) {
                throw new IllegalStateException("No existe apertura de caja para la fecha indicada. No se puede cerrar.");
            }

            // Control de arqueo: Monto físico debe coincidir con lo esperado.
            BigDecimal ingresos = sumByDateAndTipo(em, f, CajaMovimiento.TipoMovimiento.CREDITO);
            BigDecimal egresos = sumByDateAndTipo(em, f, CajaMovimiento.TipoMovimiento.DEBITO);
            BigDecimal esperado = apertura.getMonto().add(ingresos).subtract(egresos);

            if (montoFinal == null) {
                throw new IllegalStateException("Debe ingresar el monto físico de cierre.");
            }
            if (montoFinal.compareTo(esperado) != 0) {
                BigDecimal diferencia = montoFinal.subtract(esperado);
                throw new IllegalStateException(
                        "El monto físico NO coincide con el esperado. Esperado: " + esperado +
                        " | Ingresado: " + montoFinal +
                        " | Diferencia: " + diferencia +
                        ". Corrija el monto antes de cerrar la caja."
                );
            }

            CajaMovimiento cierre = new CajaMovimiento();
            cierre.setMonto(montoFinal);
            cierre.setTipoMovimiento(TipoMovimiento.CIERRE);
            cierre.setFecha(f);
            cierre.setDescripcion("Cierre de caja");

            if (usuario != null && usuario.getIdUsuario() != null) {
                Usuario usuarioMG = em.find(Usuario.class, usuario.getIdUsuario());
                cierre.setUsuario(usuarioMG);
            } else {
                cierre.setUsuario(null);
            }

            em.persist(cierre);
            return true;
        });
    }

    /**
     * Variante robusta: registra el cierre tomando como referencia una APERTURA por ID.
     *
     * Motivo:
     *  - En escenarios donde una caja quedó abierta el día anterior, la UI puede intentar
     *    cerrar esa caja; si hay desfasajes de normalización/UTC/local o comparaciones
     *    inconsistentes, la búsqueda por fecha puede fallar.
     *  - Al usar el ID de la apertura, se evita depender de igualdad de fechas.
     */
    public boolean registrarCierrePorAperturaId(BigDecimal montoFinal, Usuario usuario, Long idApertura) {
        return tx.runInTx(em -> {
            if (idApertura == null) {
                throw new IllegalStateException("No se indicó la apertura a cerrar.");
            }

            CajaMovimiento apertura = em.find(CajaMovimiento.class, idApertura);
            if (apertura == null || apertura.isEliminado() || apertura.getTipoMovimiento() != TipoMovimiento.APERTURA) {
                throw new IllegalStateException("No existe una apertura válida para cerrar (id=" + idApertura + ").");
            }

            Date f = onlyDate(apertura.getFecha());

            if (existeMovimientoEnFecha(em, f, TipoMovimiento.CIERRE)) {
                throw new IllegalStateException("La caja ya fue cerrada en la fecha indicada.");
            }

            // Control de arqueo: Monto físico debe coincidir con lo esperado.
            BigDecimal ingresos = sumByDateAndTipo(em, f, CajaMovimiento.TipoMovimiento.CREDITO);
            BigDecimal egresos = sumByDateAndTipo(em, f, CajaMovimiento.TipoMovimiento.DEBITO);
            BigDecimal esperado = apertura.getMonto().add(ingresos).subtract(egresos);

            if (montoFinal == null) {
                throw new IllegalStateException("Debe ingresar el monto físico de cierre.");
            }
            if (montoFinal.compareTo(esperado) != 0) {
                BigDecimal diferencia = montoFinal.subtract(esperado);
                throw new IllegalStateException(
                        "El monto físico NO coincide con el esperado. Esperado: " + esperado +
                        " | Ingresado: " + montoFinal +
                        " | Diferencia: " + diferencia +
                        ". Corrija el monto antes de cerrar la caja."
                );
            }

            CajaMovimiento cierre = new CajaMovimiento();
            cierre.setMonto(montoFinal);
            cierre.setTipoMovimiento(TipoMovimiento.CIERRE);
            cierre.setFecha(f);
            cierre.setDescripcion("Cierre de caja");

            if (usuario != null && usuario.getIdUsuario() != null) {
                Usuario usuarioMG = em.find(Usuario.class, usuario.getIdUsuario());
                cierre.setUsuario(usuarioMG);
            } else {
                cierre.setUsuario(null);
            }

            em.persist(cierre);
            return true;
        });
    }

    /**
     * Registra cierre de caja permitiendo diferencia con arqueo.
     *
     * Si el monto físico NO coincide con el esperado, crea un movimiento de ajuste
     * (DEBITO o CREDITO) por la diferencia, con motivo obligatorio, y luego registra el cierre.
     *
     * Esto mantiene trazabilidad contable sin eliminar movimientos históricos.
     */
    public boolean registrarCierreConAjuste(BigDecimal montoFisico, Usuario usuario, Date fecha, String motivo) {
        return tx.runInTx(em -> {
            Date f = onlyDate(fecha);

            if (existeMovimientoEnFecha(em, f, TipoMovimiento.CIERRE)) {
                throw new IllegalStateException("La caja ya fue cerrada en la fecha indicada.");
            }

            CajaMovimiento apertura = findAperturaByDate(em, f);
            if (apertura == null) {
                throw new IllegalStateException("No existe apertura de caja para la fecha indicada. No se puede cerrar.");
            }

            if (montoFisico == null) {
                throw new IllegalStateException("Debe ingresar el monto físico de cierre.");
            }

            String mot = motivo == null ? "" : motivo.trim();
            if (mot.isEmpty()) {
                throw new IllegalStateException("Debe ingresar un motivo para el ajuste de arqueo.");
            }

            // Esperado antes de ajuste
            BigDecimal ingresos = sumByDateAndTipo(em, f, CajaMovimiento.TipoMovimiento.CREDITO);
            BigDecimal egresos = sumByDateAndTipo(em, f, CajaMovimiento.TipoMovimiento.DEBITO);
            BigDecimal esperado = apertura.getMonto().add(ingresos).subtract(egresos);

            BigDecimal diferencia = montoFisico.subtract(esperado);

            if (diferencia.compareTo(BigDecimal.ZERO) != 0) {
                // Crear movimiento de ajuste para cuadrar al monto físico
                CajaMovimiento ajuste = new CajaMovimiento();
                ajuste.setFecha(f);
                ajuste.setDescripcion("AJUSTE ARQUEO: " + mot);

                if (diferencia.compareTo(BigDecimal.ZERO) > 0) {
                    // Sobran fondos: crédito adicional
                    ajuste.setTipoMovimiento(TipoMovimiento.CREDITO);
                    ajuste.setMonto(diferencia);
                } else {
                    // Faltan fondos: débito
                    ajuste.setTipoMovimiento(TipoMovimiento.DEBITO);
                    ajuste.setMonto(diferencia.abs());
                }

                if (usuario != null && usuario.getIdUsuario() != null) {
                    Usuario usuarioMG = em.find(Usuario.class, usuario.getIdUsuario());
                    ajuste.setUsuario(usuarioMG);
                } else {
                    ajuste.setUsuario(null);
                }

                // metodoPago y recibo nulos (ajuste interno)
                ajuste.setMetodoPago(null);
                ajuste.setRecibo(null);

                em.persist(ajuste);
            }

            // Registrar cierre con el monto físico
            CajaMovimiento cierre = new CajaMovimiento();
            cierre.setMonto(montoFisico);
            cierre.setTipoMovimiento(TipoMovimiento.CIERRE);
            cierre.setFecha(f);
            cierre.setDescripcion("Cierre de caja");

            if (usuario != null && usuario.getIdUsuario() != null) {
                Usuario usuarioMG = em.find(Usuario.class, usuario.getIdUsuario());
                cierre.setUsuario(usuarioMG);
            } else {
                cierre.setUsuario(null);
            }

            em.persist(cierre);
            return true;
        });
    }
}
