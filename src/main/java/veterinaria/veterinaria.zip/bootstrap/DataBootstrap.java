
package veterinaria.bootstrap;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import javax.swing.JButton;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import veterinaria.entidad.Configuracion;
import veterinaria.entidad.MetodoPago;
import veterinaria.entidad.Permiso;
import veterinaria.entidad.Rol;
import veterinaria.entidad.RolPermiso;
import veterinaria.entidad.RolPermisoId;
import veterinaria.persistencia.JPAUtil;
import veterinaria.util.Constantes;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class DataBootstrap {

    private static final Logger LOG = Logger.getLogger(DataBootstrap.class.getName());

    private DataBootstrap() {}

    /**
     * Crea roles base y permisos base si aún no existen.
     * Es idempotente: se puede ejecutar en cada inicio.
     */
    public static void ensureBaseSecurityData() {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();

            LOG.info("[BOOTSTRAP] Iniciando bootstrap de seguridad y datos base...");

            // Roles base (necesarios para que el login/admin bootstrap sea coherente)
            Rol rolAdmin = ensureRol(em, "Administrador");
            ensureRol(em, "Asistente");
            ensureRol(em, "Veterinario");

            // 1) Permisos: crear (si faltan) desde el seed del sistema (preferido)
            //    Si el seed no existe (ambiente dev), caer al generador por reflexión.
            seedPermisos(em);

            // 2) Asignación rol_permiso: sincronizar (aunque ya existan registros)
            //    - Si existe CSV de referencia, lo carga de forma idempotente.
            //    - Si no existe CSV, asegura una política por defecto para roles base.
            syncRolPermiso(em);

            // 3) Configuraciones base (idempotente): NO pisa lo que el usuario ya configuró
            seedConfiguraciones(em);

            // 4) Métodos de pago base (idempotente): EFECTIVO y CUENTA_CORRIENTE
            seedMetodosPago(em);

            // 5) Producto: migrar columna precio -> precio_costo (idempotente)
            ensureProductoPrecioCostoSchema(em);

            // 6) Auditoría: asegurar PK autoincremental (idempotente)
            ensureAuditoriaSchema(em);

            LOG.info("[BOOTSTRAP] Bootstrap finalizado OK.");

            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            LOG.log(Level.SEVERE, "[BOOTSTRAP] Error ejecutando bootstrap. Se hace rollback.", e);
            throw e;
        } finally {
            em.close();
        }
    }

    /**
     * Crea métodos de pago mínimos para que el sistema arranque usable en una BD vacía.
     *
     * Nota: se ejecuta dentro de la transacción del bootstrap (idempotente).
     */
    private static void seedMetodosPago(EntityManager em) {
        ensureMetodoPago(em, "Pago Efectivo", "Pago en efectivo");
        ensureMetodoPago(em, "Cuenta Corriente", "Pago a cuenta corriente / fiado");
    }

    private static MetodoPago ensureMetodoPago(EntityManager em, String nombre, String descripcion) {
        try {
            return em.createQuery("SELECT m FROM MetodoPago m WHERE m.nombre = :n", MetodoPago.class)
                    .setParameter("n", nombre)
                    .getSingleResult();
        } catch (NoResultException ex) {
            MetodoPago m = new MetodoPago();
            m.setNombre(nombre);
            m.setDescripcion(descripcion);
            em.persist(m);
            em.flush();
            return m;
        }
    }

    private static void seedConfiguraciones(EntityManager em) {

        // Turnos / Horarios (idempotente)
        ensureConfig(em, "PELUQUERIA_TURNOS_POR_DIA", "4", "(DEPRECATED) Turnos maximos por dia");
        ensureConfig(em, "PELUQUERIA_TURNOS_MANANA", "2", "Turnos maximos por la manana");
        ensureConfig(em, "PELUQUERIA_TURNOS_TARDE", "2", "Turnos maximos por la tarde");

        ensureConfig(em, "PELUQUERIA_DURACION_TURNO_MIN", "60", "Duracion del turno en minutos");

        // Horario legacy (por compatibilidad)
        ensureConfig(em, "PELUQUERIA_HORARIO_DESDE", "09:00", "(DEPRECATED) Horario desde (HH:mm)");
        ensureConfig(em, "PELUQUERIA_HORARIO_HASTA", "11:00", "(DEPRECATED) Horario hasta (HH:mm)");

        // Horarios por franja (horario cortado)
        ensureConfig(em, "PELUQUERIA_HORARIO_MANANA_DESDE", "09:00", "Horario manana desde (HH:mm)");
        ensureConfig(em, "PELUQUERIA_HORARIO_MANANA_HASTA", "11:00", "Horario manana hasta (HH:mm)");
        ensureConfig(em, "PELUQUERIA_HORARIO_TARDE_DESDE", "17:00", "Horario tarde desde (HH:mm)");
        ensureConfig(em, "PELUQUERIA_HORARIO_TARDE_HASTA", "20:00", "Horario tarde hasta (HH:mm)");

        // Dias habilitados (1=Lun ... 7=Dom)
        ensureConfig(em, "PELUQUERIA_DIAS_HABILITADOS", "1,2,3,4,5", "Dias habilitados (1=Lun..7=Dom)");

        // Laboratorio / Hospitalización (idempotente)
        ensureConfig(em, "LABORATORIO_DIAS_HABILITADOS", "1,3,5", "Laboratorio - dias habilitados (1=Lun..7=Dom)");
        ensureConfig(em, "LABORATORIO_DURACION_TURNO_MIN", "30", "Laboratorio - duracion del turno en minutos");
        // LABORATORIO_INTERVALO_EXTRACCION_HORAS eliminado: laboratorio usa turnos por duración.

        ensureConfig(em, "HOSPITALIZACION_DIAS_HABILITADOS", "2,4,6", "Hospitalizacion - dias habilitados (1=Lun..7=Dom)");
        ensureConfig(em, "HOSPITALIZACION_DURACION_TURNO_MIN", "60", "Hospitalizacion - duracion del turno en minutos");


    }

    private static void ensureConfig(EntityManager em, String clave, String valorDefault, String descripcion) {
        try {
            em.createQuery("SELECT c FROM Configuracion c WHERE c.clave = :k", Configuracion.class)
                    .setParameter("k", clave)
                    .getSingleResult();
            // Existe: no tocar (no pisar el valor del usuario)
            return;
        } catch (NoResultException ex) {
            Configuracion c = new Configuracion();
            c.setClave(clave);
            c.setValor(valorDefault);
            c.setDescripcion(descripcion);
            em.persist(c);
        }
    }

    private static Rol ensureRol(EntityManager em, String nombreRol) {
        try {
            return em.createQuery("SELECT r FROM Rol r WHERE r.nombreRol = :n", Rol.class)
                    .setParameter("n", nombreRol)
                    .getSingleResult();
        } catch (NoResultException ex) {
            Rol r = new Rol();
            r.setNombreRol(nombreRol);
            em.persist(r);
            em.flush();
            return r;
        }
    }

    private static void seedPermisos(EntityManager em) {
        if (seedPermisosFromResource(em)) {
            return;
        }

        // Fallback por reflexión (dev): formularios + botones
        Set<String> permisos = new LinkedHashSet<>();

        // 1) Permisos de acceso a formularios (mismo nombre que usa MainForm: simpleName)
        List<Class<?>> forms = getFormsList();
        for (Class<?> formClass : forms) {
            String formName = formClass.getSimpleName();
            permisos.add(formName);

            // 2) Permisos por acción (FormX.ACCION) a partir de campos JButton (convención PermisoUI)
            for (Field f : formClass.getDeclaredFields()) {
                // Evitar falsos positivos: solo consideramos acciones si el campo es un JButton
                // (los formularios suelen tener muchos strings/labels/campos cuyo nombre podría matchear)
                if (!JButton.class.isAssignableFrom(f.getType())) {
                    continue;
                }
                String action = mapActionFromFieldName(f.getName());
                if (action != null) {
                    permisos.add(formName + "." + action);
                }
            }
        }

        // Compatibilidad histórica: en algunos dumps/instalaciones el permiso de configuración
        // se llamaba "FormConfiguracion", pero en el proyecto el formulario real es "ClassConfig".
        // Seedear ambos evita problemas en entornos mixtos.
        permisos.add("ClassConfig");
        permisos.add("FormConfiguracion");

        // Inserta si no existe
        for (String nombrePermiso : permisos) {
            ensurePermiso(em, nombrePermiso, null, null);
        }
    }

    private static void ensurePermiso(EntityManager em, String nombrePermiso, String desc, String tipo) {
        Permiso p;
        try {
            p = em.createQuery("SELECT p FROM Permiso p WHERE p.nombrePermiso = :n", Permiso.class)
                    .setParameter("n", nombrePermiso)
                    .getSingleResult();
        } catch (NoResultException ex) {
            p = null;
        }

        if (p != null) {
            return;
        }

        Permiso nuevo = new Permiso();
        nuevo.setNombrePermiso(nombrePermiso);

        // Si viene del seed, respetar tal cual. Si no, derivar.
        if (tipo != null && !tipo.trim().isEmpty()) {
            nuevo.setTipoPermiso(tipo);
        } else {
            nuevo.setTipoPermiso(nombrePermiso.contains(".")
                    ? Constantes.TipoPermiso.FUNCIONALIDAD.name()
                    : Constantes.TipoPermiso.FORMULARIO.name());
        }

        if (desc != null && !desc.trim().isEmpty()) {
            nuevo.setDescPermiso(desc);
        } else {
            if (nombrePermiso.contains(".")) {
                String[] parts = nombrePermiso.split("\\.");
                String form = parts.length > 0 ? parts[0] : "Formulario";
                String action = parts.length > 1 ? parts[1] : "ACCION";
                // Mantener estilo similar al dump SQL ("Guardar/Registrar en X", etc.)
                nuevo.setDescPermiso(actionToDesc(action) + " en " + prettyFormName(form));
            } else {
                nuevo.setDescPermiso("Acceso al formulario de " + prettyFormName(nombrePermiso));
            }
        }

        em.persist(nuevo);
        // Asegurar que el ID autogenerado quede disponible en esta misma transacción.
        // Esto evita que la sincronización de rol_permiso (que usa RolPermisoId)
        // saltee permisos recién creados por tener idPermiso == null.
        em.flush();
    }

    private static boolean seedPermisosFromResource(EntityManager em) {
        try {
            InputStream is = DataBootstrap.class.getClassLoader().getResourceAsStream("bootstrap/permisos_seed.csv");
            if (is == null) {
                return false;
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line;
                boolean header = true;
                while ((line = br.readLine()) != null) {
                    if (header) { header = false; continue; }
                    if (line.trim().isEmpty()) continue;
                    String[] parts = line.split(";", -1);
                    if (parts.length < 1) continue;
                    String nombre = parts[0].trim();
                    String desc = parts.length > 1 ? parts[1].trim() : null;
                    String tipo = parts.length > 2 ? parts[2].trim() : null;
                    if (!nombre.isEmpty()) {
                        ensurePermiso(em, nombre, desc, tipo);
                    }
                }
            }
            return true;
        } catch (Exception e) {
            // Ante cualquier error del seed, caer al fallback
            return false;
        }
    }

    /**
     * Sincroniza la matriz rol_permiso.
     *
     * Problema real que resuelve:
     * - Si rol_permiso tiene SOLO Administrador (caso típico tras reset + primer login),
     *   el flujo anterior salía y dejaba Asistente/Veterinario SIN permisos.
     *
     * Política:
     * 1) Si existe resource bootstrap/rol_permiso_seed.csv, se carga de forma idempotente (sin duplicados).
     * 2) Si NO existe resource, se asegura un default razonable:
     *    - Administrador: TODO acceso.
     *    - Asistente: acceso a operación general, SIN configuración/usuarios.
     *    - Veterinario: acceso clínico/turnos, SIN caja/stock/proveedores/config/usuarios.
     */
    private static void syncRolPermiso(EntityManager em) {
        Long total = em.createQuery("SELECT COUNT(rp) FROM RolPermiso rp", Long.class).getSingleResult();
        LOG.info("[BOOTSTRAP] rol_permiso existentes: " + (total == null ? 0 : total));

        // 1) Si existe un seed de referencia, cargarlo (idempotente) siempre.
        boolean seeded = seedRolPermisoFromResourceIdempotent(em);
        if (seeded) {
            LOG.info("[BOOTSTRAP] rol_permiso sincronizado desde CSV (idempotente)." );
            return;
        }

        // 2) Fallback default (sin CSV)
        Rol admin = ensureRol(em, "Administrador");
        Rol asist = ensureRol(em, "Asistente");
        Rol vet = ensureRol(em, "Veterinario");

        List<Permiso> allPerms = em.createQuery("SELECT p FROM Permiso p", Permiso.class).getResultList();

        int created = 0;
        created += ensureRoleMatrixDefault(em, admin, allPerms);
        created += ensureRoleMatrixDefault(em, asist, allPerms);
        created += ensureRoleMatrixDefault(em, vet, allPerms);

        LOG.info("[BOOTSTRAP] rol_permiso default sincronizado. Nuevos registros creados: " + created);
    }

    /**
     * Carga el CSV de rol_permiso si existe, pero en modo idempotente:
     * - No duplica registros.
     * - Si existe un registro, NO lo pisa.
     */
    private static boolean seedRolPermisoFromResourceIdempotent(EntityManager em) {
        try {
            InputStream is = DataBootstrap.class.getClassLoader().getResourceAsStream("bootstrap/rol_permiso_seed.csv");
            if (is == null) {
                return false;
            }

            int created = 0;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line;
                boolean header = true;
                while ((line = br.readLine()) != null) {
                    if (header) { header = false; continue; }
                    if (line.trim().isEmpty()) continue;
                    String[] parts = line.split(";", -1);
                    if (parts.length < 3) continue;
                    String nombreRol = parts[0].trim();
                    String nombrePermiso = parts[1].trim();
                    String accesoRaw = parts[2].trim();
                    boolean acceso = "1".equals(accesoRaw)
                            || "true".equalsIgnoreCase(accesoRaw)
                            || "b'1'".equalsIgnoreCase(accesoRaw);

                    Rol rol = ensureRol(em, nombreRol);
                    Permiso permiso;
                    try {
                        permiso = em.createQuery("SELECT p FROM Permiso p WHERE p.nombrePermiso = :n", Permiso.class)
                                .setParameter("n", nombrePermiso)
                                .getSingleResult();
                    } catch (NoResultException ex) {
                        ensurePermiso(em, nombrePermiso, null, null);
                        permiso = em.createQuery("SELECT p FROM Permiso p WHERE p.nombrePermiso = :n", Permiso.class)
                                .setParameter("n", nombrePermiso)
                                .getSingleResult();
                    }

                    if (ensureRolPermisoIfMissing(em, rol, permiso, acceso)) {
                        created++;
                    }
                }
            }

            LOG.info("[BOOTSTRAP] CSV rol_permiso procesado. Nuevos registros: " + created);
            return true;
        } catch (Exception e) {
            // Ante cualquier error del seed, caer al fallback
            LOG.log(Level.WARNING, "[BOOTSTRAP] No se pudo cargar rol_permiso_seed.csv. Se aplica fallback default.", e);
            return false;
        }
    }

    private static int ensureRoleMatrixDefault(EntityManager em, Rol rol, List<Permiso> permisos) {
        if (rol == null || rol.getIdRol() == null) return 0;

        // Traer permisos ya asignados para evitar duplicados y reducir queries.
        List<Integer> existing = em.createQuery(
                "SELECT rp.permiso.idPermiso FROM RolPermiso rp WHERE rp.rol.idRol = :rid",
                Integer.class)
                .setParameter("rid", rol.getIdRol())
                .getResultList();
        HashSet<Integer> existingSet = new HashSet<>(existing);

        int created = 0;
        for (Permiso p : permisos) {
            if (p == null || p.getIdPermiso() == null) continue;
            if (existingSet.contains(p.getIdPermiso())) {
                continue; // ya existe
            }

            boolean acceso = defaultAccessForRole(rol.getNombreRol(), p.getNombrePermiso());
            RolPermiso rp = new RolPermiso();
            rp.setRol(rol);
            rp.setPermiso(p);
            rp.setAcceso(acceso);
            rp.setId(new RolPermisoId(rol.getIdRol(), p.getIdPermiso()));
            em.persist(rp);
            created++;
        }

        if (created > 0) {
            LOG.info("[BOOTSTRAP] Se asignaron " + created + " permisos faltantes al rol '" + rol.getNombreRol() + "'.");
        } else {
            LOG.info("[BOOTSTRAP] Rol '" + rol.getNombreRol() + "' ya tenía permisos (o no había nuevos para asignar).");
        }
        return created;
    }

    private static boolean ensureRolPermisoIfMissing(EntityManager em, Rol rol, Permiso permiso, boolean acceso) {
        if (rol == null || permiso == null || rol.getIdRol() == null || permiso.getIdPermiso() == null) {
            return false;
        }

        Long exists = em.createQuery(
                "SELECT COUNT(rp) FROM RolPermiso rp WHERE rp.id.idRol = :rid AND rp.id.idPermiso = :pid",
                Long.class)
                .setParameter("rid", rol.getIdRol())
                .setParameter("pid", permiso.getIdPermiso())
                .getSingleResult();

        if (exists != null && exists > 0) {
            return false;
        }

        RolPermiso rp = new RolPermiso();
        rp.setRol(rol);
        rp.setPermiso(permiso);
        rp.setAcceso(acceso);
        rp.setId(new RolPermisoId(rol.getIdRol(), permiso.getIdPermiso()));
        em.persist(rp);
        return true;
    }

    private static boolean defaultAccessForRole(String nombreRol, String nombrePermiso) {
        if (nombreRol == null || nombrePermiso == null) return false;

        // Administrador: todo
        if ("Administrador".equalsIgnoreCase(nombreRol)) {
            return true;
        }

        // Derivar formulario base (antes del punto)
        String form = nombrePermiso;
        int dot = nombrePermiso.indexOf('.');
        if (dot > 0) {
            form = nombrePermiso.substring(0, dot);
        }

        // Bloqueos globales (seguridad/config)
        boolean isSecurityOrConfig = "FormUsuario".equalsIgnoreCase(form)
                || "ClassConfig".equalsIgnoreCase(form)
                || "FormConfiguracion".equalsIgnoreCase(form);

        if ("Asistente".equalsIgnoreCase(nombreRol)) {
            // Asistente: operación general, NO administración/seguridad
            if (isSecurityOrConfig) {
                return false;
            }
            return true;
        }

        if ("Veterinario".equalsIgnoreCase(nombreRol)) {
            // Veterinario: acceso clínico/turnos. Se bloquea caja/stock/compras/seguridad/config.
            if (isSecurityOrConfig) {
                return false;
            }

            // Bloquear módulos no clínicos
            if (form.startsWith("FormCaja")
                    || form.startsWith("FormInformesCaja")
                    || form.startsWith("FormProducto")
                    || form.startsWith("FormStock")
                    || form.startsWith("FormProveedores")
                    || form.startsWith("FormOrdenesCompra")
                    || form.startsWith("FormRecibirPedido")
                    || form.startsWith("FormGestionCuentasCorrientes")
                    || form.startsWith("FormCuentaCorriente")) {
                return false;
            }

            // Permitidos (clínicos + turnos + clientes/mascotas)
            if (form.startsWith("FormCliente")
                    || form.startsWith("FormMascota")
                    || form.startsWith("FormVisita")
                    || form.startsWith("FormHistoriaClinica")
                    || form.startsWith("FormLaboratorio")
                    || form.startsWith("FormHospitalizaciones")
                    || form.startsWith("FormProcedimientos")
                    || form.startsWith("FormTurnosPeluqueria")
                    || form.startsWith("FormHistorialTurnos")
                    || form.startsWith("FormAccesoRestringido")) {
                return true;
            }
            return false;
        }
        return false;
    }

    private static List<Class<?>> getFormsList() {
        List<Class<?>> list = new ArrayList<>();

        // IMPORTANT:
        // La lista debe mantenerse alineada con los formularios reales del proyecto
        // (NetBeans .form + .java), porque de aquí se derivan permisos de menú y acciones.
        // Si se agrega un nuevo FormXXX, se recomienda sumarlo aquí.

        list.addAll(Arrays.asList(
            veterinaria.vista.FormUsuario.class,
            veterinaria.vista.FormCliente.class,
            veterinaria.vista.FormMascota.class,
            veterinaria.vista.FormVisita.class,
            veterinaria.vista.FormHistoriaClinica.class,

            // Cuentas corrientes
            veterinaria.vista.FormGestionCuentasCorrientes.class,
            veterinaria.vista.FormCuentaCorrienteMovimientos.class,

            // Caja / Ventas
            veterinaria.vista.FormCajaRegistradora.class,
            veterinaria.vista.FormInformesCajaMovimientos.class,
            // veterinaria.vista.FormConsumos.class,


            // Stock / Productos
            veterinaria.vista.FormProducto.class,
            veterinaria.vista.FormStockProducto.class,

            // Proveedores / Compras
            veterinaria.vista.FormProveedores.class,
            veterinaria.vista.FormOrdenesCompra.class,
            veterinaria.vista.FormRecibirPedido.class,

            // Servicios (turnos)
            veterinaria.vista.FormLaboratorio.class,
            veterinaria.vista.FormHospitalizaciones.class,
            veterinaria.vista.FormProcedimientos.class,
            veterinaria.vista.FormTurnosPeluqueria.class,
            veterinaria.vista.FormHistorialTurnos.class,
            veterinaria.vista.PanelTiposCitaPeluqueria.class,

            // Configuración / Seguridad
            veterinaria.vista.ClassConfig.class,

            // Auditoría
            veterinaria.vista.FormAuditoria.class,

            // Pantalla informativa
            veterinaria.vista.FormAccesoRestringido.class

            // Otros
            // veterinaria.vista.FormMascotaConsumos.class
        ));
        return list;
    }

    private static String prettyFormName(String formSimpleName) {
        if (formSimpleName == null) return "Formulario";
        // Quitar prefijo Form / Class si existe
        String n = formSimpleName;
        if (n.startsWith("Form")) n = n.substring(4);
        if (n.startsWith("Class")) n = n.substring(5);
        if (n.isEmpty()) return "Formulario";
        // Separar por mayúsculas: CajaRegistradora -> Caja Registradora
        StringBuilder sb = new StringBuilder();
        char[] arr = n.toCharArray();
        for (int i = 0; i < arr.length; i++) {
            char c = arr[i];
            if (i > 0 && Character.isUpperCase(c) && Character.isLowerCase(arr[i - 1])) {
                sb.append(' ');
            }
            sb.append(c);
        }
        return sb.toString().trim();
    }

    private static String actionToDesc(String action) {
        if (action == null) return "Acción";
        switch (action) {
            case "GUARDAR":
                return "Guardar/Registrar";
            case "EDITAR":
                return "Editar/Modificar";
            case "ELIMINAR":
                return "Eliminar";
            case "NUEVO":
                return "Nuevo";
            case "IMPRIMIR":
                return "Imprimir";
            case "EXPORTAR":
                return "Exportar";
            case "REGISTRAR_VENTA":
                return "Registrar venta";
            case "REGISTRAR_COBRO_CC":
                return "Registrar cobro (CC)";
            case "AGREGAR_PRODUCTO_VENTA":
                return "Agregar producto a venta";
            case "AGREGAR_METODO_PAGO":
                return "Agregar método de pago";
            case "ABRIR_CAJA":
                return "Abrir caja";
            case "CERRAR_CAJA":
                return "Cerrar caja";
            case "ANULAR":
                return "Anular";
            case "AGREGAR":
                return "Agregar";
            case "QUITAR":
                return "Quitar";
            default:
                return "Permite " + action;
        }
    }

    // Copia (alineada) de la lógica de PermisoUI para derivar la acción desde el nombre del botón.
    private static String mapActionFromFieldName(String fieldName) {
        if (fieldName == null) return null;
        String n = fieldName.toLowerCase();

        // Caja (casos específicos primero)
        if (n.contains("cerrarcaja")) return "CERRAR_CAJA";
        if (n.contains("abrircaja")) return "ABRIR_CAJA";

        // Caja Registradora (acciones granulares)
        if (n.contains("registrarventa") || n.contains("confirmarventa")) return "REGISTRAR_VENTA";
        if (n.contains("registrarcobro")) return "REGISTRAR_COBRO_CC";
        if (n.contains("agregarproductoventa")) return "AGREGAR_PRODUCTO_VENTA";
        if (n.contains("agregarmetodopago")) return "AGREGAR_METODO_PAGO";

        // Acciones comunes
        if (n.contains("guardar") || n.contains("registrar") || n.contains("confirmar") || n.contains("grabar")) return "GUARDAR";
        if (n.contains("eliminar") || n.contains("borrar")) return "ELIMINAR";
        if (n.contains("anular")) return "ANULAR";
        if (n.contains("editar") || n.contains("modificar") || n.contains("actualizar")) return "EDITAR";
        if (n.contains("nuevo")) return "NUEVO";
        if (n.contains("agregar") || n.contains("add")) return "AGREGAR";
        if (n.contains("quitar") || n.contains("remover") || n.contains("remove")) return "QUITAR";
        if (n.contains("imprimir") || n.contains("print")) return "IMPRIMIR";
        if (n.contains("export")) return "EXPORTAR";

        // Cancelar/limpiar normalmente no se restringen
        return null;
    }


/**
 * Asegura que la tabla AUDITORIA tenga PK autoincremental compatible con Hibernate.
 * Soluciona el error: "Field 'id_auditoria' doesn't have a default value".
 *
 * Es idempotente y tolerante: si falla, no aborta el arranque.
 */
private static void ensureAuditoriaSchema(EntityManager em) {
    try {
        // ¿Existe tabla auditoria?
        List<?> t = em.createNativeQuery("SHOW TABLES LIKE 'auditoria'").getResultList();
        if (t == null || t.isEmpty()) {
            return;
        }

        // Si la columna se llama "id" (algunas migraciones), la renombramos.
        List<?> colId = em.createNativeQuery("SHOW COLUMNS FROM auditoria LIKE 'id'").getResultList();
        List<?> colIdAud = em.createNativeQuery("SHOW COLUMNS FROM auditoria LIKE 'id_auditoria'").getResultList();

        if ((colIdAud == null || colIdAud.isEmpty()) && colId != null && !colId.isEmpty()) {
            // Renombrar id -> id_auditoria con AI
            em.createNativeQuery("ALTER TABLE auditoria CHANGE COLUMN id id_auditoria BIGINT NOT NULL AUTO_INCREMENT").executeUpdate();
        }

        // Asegurar columna id_auditoria
        colIdAud = em.createNativeQuery("SHOW COLUMNS FROM auditoria LIKE 'id_auditoria'").getResultList();
        if (colIdAud == null || colIdAud.isEmpty()) {
            // Si no existe, la agregamos
            em.createNativeQuery("ALTER TABLE auditoria ADD COLUMN id_auditoria BIGINT NOT NULL AUTO_INCREMENT").executeUpdate();
        }

        // Forzar AUTO_INCREMENT (por si existe pero sin AI)
        em.createNativeQuery("ALTER TABLE auditoria MODIFY COLUMN id_auditoria BIGINT NOT NULL AUTO_INCREMENT").executeUpdate();

        // Asegurar PK en id_auditoria
        List<?> pk = em.createNativeQuery("SHOW KEYS FROM auditoria WHERE Key_name = 'PRIMARY'").getResultList();
        if (pk == null || pk.isEmpty()) {
            em.createNativeQuery("ALTER TABLE auditoria ADD PRIMARY KEY (id_auditoria)").executeUpdate();
        }

    } catch (Exception ex) {
        LOG.log(Level.WARNING, "[BOOTSTRAP] No se pudo asegurar esquema de AUDITORIA: " + ex.getMessage());
    }
}

/**
 * Migra la columna producto.precio a producto.precio_costo para evitar ambigüedad
 * entre costo y venta. Es idempotente y tolerante.
 */
private static void ensureProductoPrecioCostoSchema(EntityManager em) {
    try {
        List<?> t = em.createNativeQuery("SHOW TABLES LIKE 'producto'").getResultList();
        if (t == null || t.isEmpty()) {
            return;
        }

        List<?> colCosto = em.createNativeQuery("SHOW COLUMNS FROM producto LIKE 'precio_costo'").getResultList();
        if (colCosto != null && !colCosto.isEmpty()) {
            return;
        }

        List<?> colPrecio = em.createNativeQuery("SHOW COLUMNS FROM producto LIKE 'precio'").getResultList();
        if (colPrecio != null && !colPrecio.isEmpty()) {
            em.createNativeQuery("ALTER TABLE producto CHANGE COLUMN precio precio_costo DOUBLE NULL").executeUpdate();
            LOG.info("[BOOTSTRAP] Columna producto.precio migrada a producto.precio_costo");
            return;
        }

        em.createNativeQuery("ALTER TABLE producto ADD COLUMN precio_costo DOUBLE NULL").executeUpdate();
        LOG.info("[BOOTSTRAP] Columna producto.precio_costo creada");
    } catch (Exception ex) {
        LOG.log(Level.WARNING, "[BOOTSTRAP] No se pudo asegurar esquema de PRODUCTO.precio_costo: " + ex.getMessage());
    }
}
}
