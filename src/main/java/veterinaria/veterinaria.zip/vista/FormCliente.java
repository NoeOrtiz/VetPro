
package veterinaria.vista;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingUtilities;
import javax.swing.event.TableModelEvent;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import veterinaria.controlador.ClienteControlador;
import veterinaria.entidad.Cliente;
import veterinaria.entidad.Persona;
import veterinaria.persistencia.ClienteDAO;
import veterinaria.persistencia.PersonaDAO;
import veterinaria.reportes.core.ReporteRequest;
import veterinaria.reportes.core.ReporteService;
import veterinaria.reportes.core.ReporteTipo;
import veterinaria.util.ManejoTablas;
import veterinaria.util.SesionUsuario;
import veterinaria.util.Validaciones;
import veterinaria.vista.application.Application;
import veterinaria.util.PermisoUI;

public class FormCliente extends javax.swing.JPanel {
    private SesionUsuario sesion = Application.getSesionUsuario();
    private final ClienteDAO clienteDAO = new ClienteDAO();
    private final PersonaDAO personaDAO = new PersonaDAO();
    private final Validaciones validar = new Validaciones(); 
    private final ManejoTablas operarTablas = new ManejoTablas();
    private Persona persona = new Persona();
    private Cliente cliente = new Cliente();

    // Índices de columnas de JTable (evita errores por cambios de orden)
    private static final int COL_SELECCION = 0;
    private static final int COL_ID_CLIENTE = 1;
    private static final int COL_NOMBRE = 2;
    private static final int COL_APELLIDO = 3;
    private static final int COL_DNI = 4;
    private static final int COL_DIRECCION = 5;
    private static final int COL_EMAIL = 6;
    private static final int COL_TELEFONO = 7;
    private static final int COL_RAZON_SOCIAL = 8;
    private static final int COL_CUIT = 9;

// Valores originales para confirmar edición (patrón FormUsuario)
private String originalNombre = "";
private String originalApellido = "";
private String originalDni = "";
private String originalDireccion = "";
private String originalTelefono = "";
private String originalEmail = "";
private String originalRazonSocial = "";
private String originalCuit = "";

    
    public FormCliente() {
        initComponents();
        PermisoUI.aplicar(this);
        btnImprimir.setVisible(false);
        initListeners();
        cargarClientesEnTabla();
        ocultarColumnaIdCliente();
        List<Integer> indicesColumnasConTooltip = Arrays.asList(COL_DNI, COL_DIRECCION, COL_EMAIL, COL_TELEFONO, COL_RAZON_SOCIAL);
        operarTablas.mouseTooltipText(tableClientes ,indicesColumnasConTooltip);
        jpDatosPersonales.setVisible(false);
    }

    @SuppressWarnings("unchecked")

    private void initListeners() {
        // Columnas para filtro/búsqueda (Nombre, Apellido, DNI, Email, Razón Social, CUIT)
        List<Integer> columnasObjetivo = Arrays.asList(COL_NOMBRE, COL_APELLIDO, COL_DNI, COL_EMAIL, COL_RAZON_SOCIAL, COL_CUIT);
        operarTablas.aplicarFiltroYResaltado(tableClientes, txtBusqueda, columnasObjetivo);

        // Visibilidad del botón Imprimir según selección (checkbox col 0)
        tableClientes.getModel().addTableModelListener(e -> {
            if (e.getType() == TableModelEvent.UPDATE && (e.getColumn() == 0 || e.getColumn() == TableModelEvent.ALL_COLUMNS)) {
                SwingUtilities.invokeLater(this::actualizarBotonImprimir);
            }
        });

        // Asegurar selección única en checkbox (columna 0) (patrón común)
        operarTablas.asegurarSeleccionUnica(tableClientes);

        // Click en fila => marcar automáticamente el checkbox (como en otros formularios)
        tableClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                seleccionarFilaDesdeClick(evt);
            }
        });

        SwingUtilities.invokeLater(this::actualizarBotonImprimir);
        
        txtApellido.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                // Este método se ejecuta cuando el txtField1 gana el foco (opcional)
            }

            @Override
            public void focusLost(FocusEvent e) {
                // Acción a realizar cuando txtField1 pierde el foco (al tabear o cambiar de campo)
                String nombreApellido = txtNombre.getText() + " " + txtApellido.getText();
                txtRazonSocial.setText(nombreApellido);
            }
        });
        
        txtRazonSocial.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                String nombreApellido = txtNombre.getText() + " " + txtApellido.getText();
                txtRazonSocial.setText(nombreApellido);
            }

            @Override
            public void focusLost(FocusEvent e) {
                // Acción a realizar cuando txtField1 pierde el foco (al tabear o cambiar de campo)
            }
        });
    } 

    /**
     * Al hacer click en una fila (fuera del checkbox), marca automáticamente el checkbox
     * de esa fila y desmarca el resto.
     */
    private void seleccionarFilaDesdeClick(java.awt.event.MouseEvent evt) {
        if (evt == null) {
            return;
        }

        int viewRow = tableClientes.rowAtPoint(evt.getPoint());
        int viewCol = tableClientes.columnAtPoint(evt.getPoint());

        if (viewRow < 0) {
            return;
        }

        // Asegurar selección visual de la fila clickeada
        try {
            tableClientes.setRowSelectionInterval(viewRow, viewRow);
        } catch (Exception ignore) {
        }

        // Si el usuario clickea directamente el checkbox, no forzamos el valor (permitimos toggle)
        if (viewCol == COL_SELECCION) {
            SwingUtilities.invokeLater(this::actualizarBotonImprimir);
            return;
        }

        // Marcar la fila clickeada y desmarcar el resto
        try {
            for (int i = 0; i < tableClientes.getRowCount(); i++) {
                if (i != viewRow && Boolean.TRUE.equals(tableClientes.getValueAt(i, 0))) {
                    tableClientes.setValueAt(false, i, 0);
                }
            }
            tableClientes.setValueAt(true, viewRow, 0);
        } catch (Exception ignore) {
        }

        SwingUtilities.invokeLater(this::actualizarBotonImprimir);
    }
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelBotones = new javax.swing.JPanel();
        lbUsuarioBusqueda = new javax.swing.JLabel();
        txtBusqueda = new javax.swing.JTextField();
        btnNuevo = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        lbBuscar = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        btnImprimir = new javax.swing.JButton();
        jpDatosPersonales = new javax.swing.JPanel();
        lbNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        lbTelefono = new javax.swing.JLabel();
        txtDNI = new javax.swing.JTextField();
        lbDireccion = new javax.swing.JLabel();
        txtApellido = new javax.swing.JTextField();
        lbApellido = new javax.swing.JLabel();
        lbDatosPersonales = new javax.swing.JLabel();
        lbDireccion2 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        jSeparator7 = new javax.swing.JSeparator();
        lbEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        txtRazonSocial = new javax.swing.JTextField();
        lbRazonSocial = new javax.swing.JLabel();
        txtCUIT = new javax.swing.JTextField();
        lbCUIT = new javax.swing.JLabel();
        lbValidacionCuit = new javax.swing.JLabel();
        panelLista = new javax.swing.JPanel();
        lbListCli = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        scroll = new javax.swing.JScrollPane();
        tableClientes = new javax.swing.JTable();
        btnImprimirLista = new javax.swing.JButton();

        lbUsuarioBusqueda.setText("BUSCAR CLIENTE");

        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        lbBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/veterinaria/icon/png/search.png"))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Gestión de Clientes");

        btnImprimir.setText("Imprimir");
        btnImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBotonesLayout = new javax.swing.GroupLayout(panelBotones);
        panelBotones.setLayout(panelBotonesLayout);
        panelBotonesLayout.setHorizontalGroup(
            panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator2)
            .addGroup(panelBotonesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelBotonesLayout.createSequentialGroup()
                        .addComponent(lbBuscar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 261, Short.MAX_VALUE)
                        .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelBotonesLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panelBotonesLayout.createSequentialGroup()
                        .addComponent(lbUsuarioBusqueda)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnImprimir, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panelBotonesLayout.setVerticalGroup(
            panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBotonesLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelBotonesLayout.createSequentialGroup()
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lbUsuarioBusqueda))
                    .addComponent(btnImprimir))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelBotonesLayout.createSequentialGroup()
                        .addGroup(panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnNuevo)
                            .addComponent(btnEditar)
                            .addComponent(btnEliminar))
                        .addGap(14, 14, 14))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBotonesLayout.createSequentialGroup()
                        .addComponent(lbBuscar)
                        .addGap(18, 18, 18)))
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jpDatosPersonales.setMinimumSize(new java.awt.Dimension(0, 0));
        jpDatosPersonales.setPreferredSize(new java.awt.Dimension(838, 0));

        lbNombre.setText("Nombre: *");

        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });

        txtTelefono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTelefonoKeyTyped(evt);
            }
        });

        lbTelefono.setText("Teléfono: ");

        txtDNI.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDNIKeyTyped(evt);
            }
        });

        lbDireccion.setText("DNI: *");

        txtApellido.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtApellidoKeyTyped(evt);
            }
        });

        lbApellido.setText("Apellido: *");

        lbDatosPersonales.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lbDatosPersonales.setText("Datos Personales:");

        lbDireccion2.setText("Dirección: *");

        lbEmail.setText("Email: *");

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        lbRazonSocial.setText("Razon Social:");

        lbCUIT.setText("CUIT:");

        lbValidacionCuit.setForeground(java.awt.Color.green);

        javax.swing.GroupLayout jpDatosPersonalesLayout = new javax.swing.GroupLayout(jpDatosPersonales);
        jpDatosPersonales.setLayout(jpDatosPersonalesLayout);
        jpDatosPersonalesLayout.setHorizontalGroup(
            jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpDatosPersonalesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator7)
                    .addGroup(jpDatosPersonalesLayout.createSequentialGroup()
                        .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbDatosPersonales)
                            .addGroup(jpDatosPersonalesLayout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jpDatosPersonalesLayout.createSequentialGroup()
                                        .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lbNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(lbApellido))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lbDireccion)
                                            .addComponent(txtDNI, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(lbDireccion2)))
                                    .addGroup(jpDatosPersonalesLayout.createSequentialGroup()
                                        .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lbEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lbTelefono)
                                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lbRazonSocial)
                                            .addComponent(txtRazonSocial, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtCUIT, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(lbCUIT)
                                            .addComponent(lbValidacionCuit, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpDatosPersonalesLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jpDatosPersonalesLayout.setVerticalGroup(
            jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpDatosPersonalesLayout.createSequentialGroup()
                .addComponent(lbDatosPersonales)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jpDatosPersonalesLayout.createSequentialGroup()
                        .addComponent(lbRazonSocial)
                        .addGap(28, 28, 28))
                    .addComponent(txtRazonSocial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jpDatosPersonalesLayout.createSequentialGroup()
                        .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jpDatosPersonalesLayout.createSequentialGroup()
                                .addComponent(lbDireccion2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpDatosPersonalesLayout.createSequentialGroup()
                                .addComponent(lbApellido)
                                .addGap(28, 28, 28))
                            .addGroup(jpDatosPersonalesLayout.createSequentialGroup()
                                .addComponent(lbNombre)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpDatosPersonalesLayout.createSequentialGroup()
                                .addComponent(lbDireccion)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtDNI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(34, 34, 34)
                        .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpDatosPersonalesLayout.createSequentialGroup()
                                .addComponent(lbTelefono)
                                .addGap(28, 28, 28))
                            .addComponent(txtTelefono, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpDatosPersonalesLayout.createSequentialGroup()
                                .addComponent(lbEmail)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpDatosPersonalesLayout.createSequentialGroup()
                                .addComponent(lbCUIT)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtCUIT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbValidacionCuit, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jpDatosPersonalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar)
                    .addComponent(btnLimpiar)
                    .addComponent(btnCancelar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11))
        );

        lbListCli.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lbListCli.setText("Lista de Clientes");

        scroll.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));

        tableClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Seleccionar", "ID", "Nombre", "Apellido", "DNI", "Dirección", "E-mail", "Teléfono", "Razon Social", "CUIT"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Boolean.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                true, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableClientes.setMinimumSize(new java.awt.Dimension(0, 0));
        tableClientes.setPreferredSize(new java.awt.Dimension(848, 220));
        tableClientes.getTableHeader().setReorderingAllowed(false);
        scroll.setViewportView(tableClientes);

        btnImprimirLista.setText("Imprimir Lista");
        btnImprimirLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimirListaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelListaLayout = new javax.swing.GroupLayout(panelLista);
        panelLista.setLayout(panelListaLayout);
        panelListaLayout.setHorizontalGroup(
            panelListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scroll, javax.swing.GroupLayout.DEFAULT_SIZE, 838, Short.MAX_VALUE)
            .addGroup(panelListaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbListCli)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnImprimirLista))
            .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        panelListaLayout.setVerticalGroup(
            panelListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelListaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbListCli)
                    .addComponent(btnImprimirLista))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 9, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scroll, javax.swing.GroupLayout.DEFAULT_SIZE, 76, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(panelBotones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panelLista, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jpDatosPersonales, javax.swing.GroupLayout.DEFAULT_SIZE, 844, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelBotones, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jpDatosPersonales, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelLista, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        Application.actualizarEstadoUsuario("CreandoCliente");

        validar.configurarValidacionCUIT(txtCUIT, lbValidacionCuit);
        btnNuevo.setEnabled(false);
        btnEditar.setEnabled(false);
        btnEliminar.setEnabled(false);
        jpDatosPersonales.setVisible(true);
        panelLista.setVisible(false);
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        // Permisos por RBAC (sin hardcodear rol)
        String perm = "FormCliente.EDITAR";
        if (sesion != null && sesion.puede(perm)) {
            Application.actualizarEstadoUsuario("EditandoCliente");
            actualizarCliente();
        } else {
            JOptionPane.showMessageDialog(
                    null,
                    "No tienes permisos suficientes para editar clientes.",
                    "Acceso restringido",
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        Integer selectedRow = operarTablas.comprobarElementoSeleccionado(tableClientes);

        // Permisos por RBAC (sin hardcodear rol)
        String perm = "FormCliente.ELIMINAR";
        if (sesion == null || !sesion.puede(perm)) {
            JOptionPane.showMessageDialog(
                    null,
                    "No tienes permisos suficientes para eliminar clientes.",
                    "Acceso restringido",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        if (selectedRow != -1) {
            Application.actualizarEstadoUsuario("EliminandoCliente");

            int respuesta = JOptionPane.showConfirmDialog(
                    this, "¿Estás seguro de que deseas eliminar este cliente?",
                    "Confirmar eliminación",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );

            if (respuesta == JOptionPane.YES_OPTION) {
                Application.actualizarEstadoUsuario("Eliminando");
                eliminarClienteSeleccionado();
                limpiarForm();
                jpDatosPersonales.setVisible(false);
                cargarClientesEnTabla();
            } else {
                Application.actualizarEstadoUsuario("Eliminación cancelada");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Por favor seleccione un cliente a ELIMINAR", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        limpiarForm();
        jpDatosPersonales.setVisible(false);
        btnNuevo.setEnabled(true);
        btnEditar.setEnabled(true);
        btnEliminar.setEnabled(true);
        tableClientes.setVisible(true);
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpiarForm();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        if (validarDatosCliente()) {

            // Confirmación SI/NO al crear o editar (patrón FormUsuario)
            if ("CreandoCliente".equals(Application.consultarEstadoUsuario())) {
                if (!confirmarCreacionCliente()) {
                    return;
                }
            }

            if ("EditandoCliente".equals(Application.consultarEstadoUsuario())) {
                if (!confirmarEdicionCliente()) {
                    return;
                }
            }

            if (persistirCliente()) {
                limpiarForm();
                panelLista.setVisible(true);
                jpDatosPersonales.setVisible(false);
                cargarClientesEnTabla();
                btnNuevo.setEnabled(true);
                btnEditar.setEnabled(true);
                btnEliminar.setEnabled(true);
            }
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void txtApellidoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApellidoKeyTyped
        validar.validarSoloLetras(evt);
    }//GEN-LAST:event_txtApellidoKeyTyped

    private void txtTelefonoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTelefonoKeyTyped
        validar.validarSoloNumeros(evt);
    }//GEN-LAST:event_txtTelefonoKeyTyped

    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped
        validar.validarSoloLetras(evt);
    }//GEN-LAST:event_txtNombreKeyTyped

    private void txtDNIKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDNIKeyTyped
        validar.validarSoloNumeros(evt);
    }//GEN-LAST:event_txtDNIKeyTyped

    private void btnImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimirActionPerformed
        imprimirRegistroSeleccionado();
    }//GEN-LAST:event_btnImprimirActionPerformed

    private void btnImprimirListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimirListaActionPerformed
        imprimirListaClientes();
    }//GEN-LAST:event_btnImprimirListaActionPerformed

    private void cargarClientesEnTabla() {
        ClienteControlador operandoCliente = new ClienteControlador();
        List<Cliente> clientes = operandoCliente.buscarTodosLosClientes();
        Persona personaCliente = new Persona();
        DefaultTableModel modelo = (DefaultTableModel) tableClientes.getModel();
        modelo.setRowCount(0);

        for (Cliente clienteBucle : clientes) {
            personaCliente = clienteBucle.getPersona();
            Object[] fila = new Object[] {
                false,
                clienteBucle.getIdCliente(),
                personaCliente.getNombre(),
                personaCliente.getApellido(),
                personaCliente.getDni(),
                personaCliente.getDireccion(),
                clienteBucle.getEmail(),
                personaCliente.getTelefono(),
                clienteBucle.getRazonSocial(),
                clienteBucle.getCuit()
            };
            modelo.addRow(fila);
        }
        actualizarBotonImprimir();
    }    

    /**
     * Oculta la columna ID para evitar que el usuario la vea, pero permite usarla
     * internamente como clave estable (evita depender del e-mail).
     */
    private void ocultarColumnaIdCliente() {
        try {
            if (tableClientes.getColumnModel().getColumnCount() > COL_ID_CLIENTE) {
                var col = tableClientes.getColumnModel().getColumn(COL_ID_CLIENTE);
                col.setMinWidth(0);
                col.setMaxWidth(0);
                col.setPreferredWidth(0);
            }
        } catch (Exception ignore) {
        }
    }

    // -------------------- Impresión PDF --------------------
    private void actualizarBotonImprimir() {
        boolean haySeleccion = (operarTablas.comprobarElementoSeleccionado(tableClientes) != -1);
        btnImprimir.setVisible(haySeleccion);
    }

    private Cliente obtenerClienteSeleccionadoDesdeTabla() {
        int row = operarTablas.comprobarElementoSeleccionado(tableClientes);
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un cliente en la tabla.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        try {
            // Columna ID (oculta): clave estable para recuperar el Cliente
            Integer idSel = null;
            Object rawId = tableClientes.getValueAt(row, COL_ID_CLIENTE);
            if (rawId instanceof Integer) {
                idSel = (Integer) rawId;
            } else if (rawId != null) {
                idSel = Integer.valueOf(String.valueOf(rawId));
            }
            if (idSel == null) {
                JOptionPane.showMessageDialog(this, "No se pudo determinar el ID del cliente seleccionado.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return null;
            }
            Cliente c = clienteDAO.buscarPorId(idSel);
            if (c == null) {
                JOptionPane.showMessageDialog(this, "No se encontró el cliente seleccionado.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return null;
            }
            return c;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "No se pudo leer el cliente seleccionado.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    private void imprimirRegistroSeleccionado() {
        Cliente c = obtenerClienteSeleccionadoDesdeTabla();
        if (c == null) return;
        try {
            // Fallback de datos planos desde la JTable (por si falla la carga de Persona)
            int rowSel = operarTablas.comprobarElementoSeleccionado(tableClientes);
            String fNombre = (rowSel != -1) ? String.valueOf(tableClientes.getValueAt(rowSel, COL_NOMBRE)) : "";
            String fApellido = (rowSel != -1) ? String.valueOf(tableClientes.getValueAt(rowSel, COL_APELLIDO)) : "";
            String fDni = (rowSel != -1) ? String.valueOf(tableClientes.getValueAt(rowSel, COL_DNI)) : "";
            String fDireccion = (rowSel != -1) ? String.valueOf(tableClientes.getValueAt(rowSel, COL_DIRECCION)) : "";
            String fEmail = (rowSel != -1) ? String.valueOf(tableClientes.getValueAt(rowSel, COL_EMAIL)) : "";
            String fTelefono = (rowSel != -1) ? String.valueOf(tableClientes.getValueAt(rowSel, COL_TELEFONO)) : "";
            String fRazonSocial = (rowSel != -1) ? String.valueOf(tableClientes.getValueAt(rowSel, COL_RAZON_SOCIAL)) : "";
            String fCuit = (rowSel != -1) ? String.valueOf(tableClientes.getValueAt(rowSel, COL_CUIT)) : "";

            // Cargar Persona vinculada (evita problemas de proxies LAZY en otros escenarios)
            Persona personaDb = null;
            try {
                if (c.getPersona() != null && c.getPersona().getIdPersona() != null) {
                    personaDb = personaDAO.obtenerPorId(c.getPersona().getIdPersona());
                }
            } catch (Exception ignore) {
                personaDb = null;
            }

            ReporteRequest req = new ReporteRequest()
                    .put("cliente", c)
                    .put("persona", personaDb)
                    .put("nombre", fNombre)
                    .put("apellido", fApellido)
                    .put("dni", fDni)
                    .put("telefono", fTelefono)
                    .put("direccion", fDireccion)
                    .put("email", fEmail)
                    .put("razonSocial", fRazonSocial)
                    .put("cuit", fCuit)
                    .put("emisor", Application.getNombreApellidoUsuarioLogeado());

            new ReporteService().generar(ReporteTipo.CLIENTE_REGISTRO, req);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo generar el registro en PDF.\n" + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void imprimirListaClientes() {
        try {
            ReporteRequest req = new ReporteRequest()
                    .put("tabla", tableClientes)
                    .put("emisor", Application.getNombreApellidoUsuarioLogeado());

            new ReporteService().generar(ReporteTipo.CLIENTE_LISTADO, req);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo generar la lista en PDF.\n" + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private boolean validarDatosCliente(){
        if (txtNombre.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "El nombre del Cliente no puede estar vacío.");
            return false;
        }
        if (txtApellido.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "El apellido del Cliente no puede estar vacío.");
            return false;
        } 
        if (txtDNI.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "El DNI del Cliente no puede estar vacío.");
            return false;
        }
        if (txtDireccion.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "La dirección del cliente no puede estar vacía.");
            return false;
        }  
        if (!validar.validarCorreoValido(txtEmail.getText().trim())) {
            JOptionPane.showMessageDialog(null, "Debes ingresar un correo válido.");
            return false;
        }
        return true;          
    }
    
    private Boolean persistirCliente() {
        Boolean retornar = false;
        
        ClienteControlador operandoCliente = new ClienteControlador();
        Cliente nuevoCliente = new Cliente();
        Persona nuevaPersona = new Persona(); 
        
        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        String dni = txtDNI.getText();
        String direccion = txtDireccion.getText();
        String telefono = txtTelefono.getText();
        String email = txtEmail.getText();
        String cuit = txtCUIT.getText();
        String razonSocial = txtRazonSocial.getText();
        
        if ("CreandoCliente".equals(Application.consultarEstadoUsuario())) {
            nuevaPersona.setNombre(nombre);
            nuevaPersona.setApellido(apellido);
            nuevaPersona.setDni(dni);
            nuevaPersona.setDireccion(direccion);
            nuevaPersona.setTelefono(telefono);

            nuevoCliente.setPersona(nuevaPersona);
            nuevoCliente.setEmail(email);
            nuevoCliente.setRazonSocial(razonSocial);
            nuevoCliente.setCuit(cuit);
            try {
                operandoCliente.crearPersonaCliente(nuevaPersona, nuevoCliente);
                JOptionPane.showMessageDialog(this, "Cliente guardado exitosamente.");
                retornar = true;
            } catch (Exception ex) {
                Logger.getLogger(FormCliente.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(this,
                        "No se pudo guardar el cliente.\n" + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            } 
        }
        
        if("EditandoCliente".equals(Application.consultarEstadoUsuario())) {
            persona.setNombre(nombre);
            persona.setApellido(apellido);
            persona.setDni(dni);
            persona.setDireccion(direccion);
            persona.setTelefono(telefono);
            cliente.setEmail(email);
            cliente.setRazonSocial(razonSocial);
            cliente.setCuit(cuit);
            try {
                operandoCliente.actualizarCliente(persona, cliente);
                JOptionPane.showMessageDialog(this, "Cliente actualizado exitosamente.");
                retornar = true;
            } catch (Exception ex) {
                Logger.getLogger(FormCliente.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(this,
                        "No se pudo actualizar el cliente.\n" + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            } 
        }
        return retornar;
    }
    
    
private boolean confirmarCreacionCliente() {
    String resumenHtml = "<html><body style='width:380px'>"
            + "<p>Confirme la creación del cliente con los siguientes datos:</p>"
            + "<b>Nombre:</b> " + escapeHtml(txtNombre.getText().trim()) + "<br>"
            + "<b>Apellido:</b> " + escapeHtml(txtApellido.getText().trim()) + "<br>"
            + "<b>DNI:</b> " + escapeHtml(txtDNI.getText().trim()) + "<br>"
            + "<b>Teléfono:</b> " + escapeHtml(txtTelefono.getText().trim()) + "<br>"
            + "<b>Dirección:</b> " + escapeHtml(txtDireccion.getText().trim()) + "<br>"
            + "<b>Email:</b> " + escapeHtml(txtEmail.getText().trim()) + "<br>"
            + "<b>Razón Social:</b> " + escapeHtml(txtRazonSocial.getText().trim()) + "<br>"
            + "<b>CUIT:</b> " + escapeHtml(txtCUIT.getText().trim())
            + "</body></html>";

    Object[] opciones = {"SI", "NO"};
    int opcion = JOptionPane.showOptionDialog(
            this,
            resumenHtml,
            "Confirmar creación de cliente",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            opciones,
            opciones[0]
    );
    return opcion == 0;
}

private boolean confirmarEdicionCliente() {
    String nuevoNombre = txtNombre.getText().trim();
    String nuevoApellido = txtApellido.getText().trim();
    String nuevoDni = txtDNI.getText().trim();
    String nuevoTelefono = txtTelefono.getText().trim();
    String nuevoDireccion = txtDireccion.getText().trim();
    String nuevoEmail = txtEmail.getText().trim();
    String nuevoRazonSocial = txtRazonSocial.getText().trim();
    String nuevoCuit = txtCUIT.getText().trim();

    StringBuilder cambios = new StringBuilder();
    cambios.append("<html><body style='width:420px'>");
    cambios.append("<p>Se modificarán los siguientes datos:</p>");

    int cambiosCount = 0;
    cambiosCount += appendCambio(cambios, "Nombre", originalNombre, nuevoNombre);
    cambiosCount += appendCambio(cambios, "Apellido", originalApellido, nuevoApellido);
    cambiosCount += appendCambio(cambios, "DNI", originalDni, nuevoDni);
    cambiosCount += appendCambio(cambios, "Teléfono", originalTelefono, nuevoTelefono);
    cambiosCount += appendCambio(cambios, "Dirección", originalDireccion, nuevoDireccion);
    cambiosCount += appendCambio(cambios, "Email", originalEmail, nuevoEmail);
    cambiosCount += appendCambio(cambios, "Razón Social", originalRazonSocial, nuevoRazonSocial);
    cambiosCount += appendCambio(cambios, "CUIT", originalCuit, nuevoCuit);

    if (cambiosCount == 0) {
        JOptionPane.showMessageDialog(this,
                "No se detectaron cambios para guardar.",
                "Sin cambios",
                JOptionPane.INFORMATION_MESSAGE);
        return false;
    }

    cambios.append("<br><p><b>¿Desea confirmar los cambios?</b></p>");
    cambios.append("</body></html>");

    Object[] opciones = {"SI", "NO"};
    int opcion = JOptionPane.showOptionDialog(
            this,
            cambios.toString(),
            "Confirmar edición de cliente",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            opciones,
            opciones[0]
    );
    return opcion == 0;
}

private void capturarOriginalesCliente() {
    originalNombre = (txtNombre.getText() == null) ? "" : txtNombre.getText().trim();
    originalApellido = (txtApellido.getText() == null) ? "" : txtApellido.getText().trim();
    originalDni = (txtDNI.getText() == null) ? "" : txtDNI.getText().trim();
    originalDireccion = (txtDireccion.getText() == null) ? "" : txtDireccion.getText().trim();
    originalTelefono = (txtTelefono.getText() == null) ? "" : txtTelefono.getText().trim();
    originalEmail = (txtEmail.getText() == null) ? "" : txtEmail.getText().trim();
    originalRazonSocial = (txtRazonSocial.getText() == null) ? "" : txtRazonSocial.getText().trim();
    originalCuit = (txtCUIT.getText() == null) ? "" : txtCUIT.getText().trim();
}

private int appendCambio(StringBuilder sb, String etiqueta, String viejo, String nuevo) {
    String v = (viejo == null) ? "" : viejo.trim();
    String n = (nuevo == null) ? "" : nuevo.trim();
    if (!v.equals(n)) {
        sb.append("<b>").append(escapeHtml(etiqueta)).append(":</b> ")
                .append(escapeHtml(v)).append(" -> ")
                .append("<b>").append(escapeHtml(n)).append("</b><br>");
        return 1;
    }
    return 0;
}

private String escapeHtml(String s) {
    if (s == null) {
        return "";
    }
    return s
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#39;");
}

private void limpiarForm() {
        txtNombre.setText("");
        txtApellido.setText("");
        txtDNI.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
        txtBusqueda.setText("");
        txtRazonSocial.setText("");
        txtCUIT.setText("");
        persona = new Persona();
        cliente = new Cliente();
        cargarClientesEnTabla();
    }
    
    private void actualizarCliente(){
        ClienteControlador operandoCliente = new ClienteControlador();
        int selectedRow = operarTablas.comprobarElementoSeleccionado(tableClientes);

        if (selectedRow != -1) {
            validar.configurarValidacionCUIT(txtCUIT, lbValidacionCuit);
            jpDatosPersonales.setVisible(true);
            panelLista.setVisible(false);
            
            Integer idSel = null;
            try {
                Object rawId = tableClientes.getValueAt(selectedRow, COL_ID_CLIENTE);
                if (rawId instanceof Integer) {
                    idSel = (Integer) rawId;
                } else if (rawId != null) {
                    idSel = Integer.valueOf(String.valueOf(rawId));
                }
            } catch (Exception ignore) {
                idSel = null;
            }

            if (idSel == null) {
                JOptionPane.showMessageDialog(this, "No se pudo determinar el ID del cliente seleccionado.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                panelLista.setVisible(true);
                jpDatosPersonales.setVisible(false);
                return;
            }

            cliente = operandoCliente.buscarPorId(idSel);
            if (cliente == null) {
                JOptionPane.showMessageDialog(this, "No se encontró el cliente seleccionado.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                panelLista.setVisible(true);
                jpDatosPersonales.setVisible(false);
                return;
            }

            persona = cliente.getPersona();
            if (persona == null) {
                JOptionPane.showMessageDialog(this, "No se encontró la persona asociada al cliente.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                panelLista.setVisible(true);
                jpDatosPersonales.setVisible(false);
                return;
            }
            txtNombre.setText(persona.getNombre());
            txtDNI.setText(persona.getDni());
            txtApellido.setText(persona.getApellido());
            txtDireccion.setText(persona.getDireccion());
            txtTelefono.setText(persona.getTelefono());
            txtEmail.setText(cliente.getEmail());
            txtRazonSocial.setText(cliente.getRazonSocial());
            txtCUIT.setText(cliente.getCuit());
            capturarOriginalesCliente();
        } else {
            JOptionPane.showMessageDialog(null, "¡Debe seleccionar un cliente para editar!", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void eliminarClienteSeleccionado(){
        ClienteControlador operandoCliente = new ClienteControlador();
        Integer selectedRow = operarTablas.comprobarElementoSeleccionado(tableClientes);

        if (selectedRow != -1) {
            Integer idSel = null;
            try {
                Object rawId = tableClientes.getValueAt(selectedRow, COL_ID_CLIENTE);
                if (rawId instanceof Integer) {
                    idSel = (Integer) rawId;
                } else if (rawId != null) {
                    idSel = Integer.valueOf(String.valueOf(rawId));
                }
            } catch (Exception ignore) {
                idSel = null;
            }

            if (idSel == null) {
                JOptionPane.showMessageDialog(this, "No se pudo determinar el ID del cliente seleccionado.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            cliente = clienteDAO.buscarPorId(idSel);
            if (cliente == null) {
                JOptionPane.showMessageDialog(this, "No se encontró el cliente seleccionado.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (cliente.getPersona() == null || cliente.getPersona().getIdPersona() == null) {
                JOptionPane.showMessageDialog(this, "El cliente no tiene una persona asociada válida.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            persona = personaDAO.obtenerPorId(cliente.getPersona().getIdPersona());
            if (persona == null) {
                JOptionPane.showMessageDialog(this, "No se encontró la persona asociada al cliente.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (operandoCliente.eliminarCliente(persona, cliente)) {
                JOptionPane.showMessageDialog(this, "Cliente eliminado con éxito", "Información", JOptionPane.INFORMATION_MESSAGE);
                cargarClientesEnTabla();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo eliminar el cliente.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnImprimir;
    private javax.swing.JButton btnImprimirLista;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JPanel jpDatosPersonales;
    private javax.swing.JLabel lbApellido;
    private javax.swing.JLabel lbBuscar;
    private javax.swing.JLabel lbCUIT;
    private javax.swing.JLabel lbDatosPersonales;
    private javax.swing.JLabel lbDireccion;
    private javax.swing.JLabel lbDireccion2;
    private javax.swing.JLabel lbEmail;
    private javax.swing.JLabel lbListCli;
    private javax.swing.JLabel lbNombre;
    private javax.swing.JLabel lbRazonSocial;
    private javax.swing.JLabel lbTelefono;
    private javax.swing.JLabel lbUsuarioBusqueda;
    private javax.swing.JLabel lbValidacionCuit;
    private javax.swing.JPanel panelBotones;
    private javax.swing.JPanel panelLista;
    private javax.swing.JScrollPane scroll;
    private javax.swing.JTable tableClientes;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBusqueda;
    private javax.swing.JTextField txtCUIT;
    private javax.swing.JTextField txtDNI;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtRazonSocial;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables

}
