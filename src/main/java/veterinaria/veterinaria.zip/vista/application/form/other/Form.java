
package veterinaria.vista.application.form.other;

public interface Form {

    void show();

}
