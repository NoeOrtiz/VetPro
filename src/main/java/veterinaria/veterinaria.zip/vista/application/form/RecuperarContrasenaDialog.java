package veterinaria.vista.application.form;

import com.formdev.flatlaf.FlatClientProperties;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Window;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import net.miginfocom.swing.MigLayout;
import veterinaria.controlador.UsuarioControlador;
import veterinaria.util.Validaciones;

public class RecuperarContrasenaDialog extends JDialog {

    private static final int ANCHO_MINIMO = 620;
    private static final int ALTO_MINIMO = 340;

    private final UsuarioControlador usuarioControlador;
    private final JTextField txtUsuario = new JTextField();
    private final JTextField txtEmail = new JTextField();
    private final JTextField txtDni = new JTextField();
    private final JPasswordField txtNuevaContrasena = new JPasswordField();
    private final JPasswordField txtRepetirContrasena = new JPasswordField();
    private final Validaciones validaciones = new Validaciones();

    public RecuperarContrasenaDialog(Window owner, UsuarioControlador usuarioControlador, String usuarioInicial) {
        super(owner instanceof Frame ? (Frame) owner : null, "Recuperar contraseña", ModalityType.APPLICATION_MODAL);
        this.usuarioControlador = usuarioControlador;
        initComponents(usuarioInicial);
    }

    private void initComponents(String usuarioInicial) {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelPrincipal = new JPanel(new BorderLayout(0, 14));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(18, 22, 14, 22));

        JPanel panelCabecera = new JPanel();
        panelCabecera.setLayout(new BoxLayout(panelCabecera, BoxLayout.Y_AXIS));

        JLabel lblTitulo = new JLabel("Restablecer acceso");
        lblTitulo.putClientProperty(FlatClientProperties.STYLE, "font:$h2.font");
        lblTitulo.setAlignmentX(LEFT_ALIGNMENT);

        JLabel lblAyuda = new JLabel("<html>Complete los datos registrados para actualizar la contraseña y volver a ingresar al sistema.</html>");
        lblAyuda.putClientProperty(FlatClientProperties.STYLE, "foreground:lighten(@foreground,25%)");
        lblAyuda.setAlignmentX(LEFT_ALIGNMENT);
        lblAyuda.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));

        panelCabecera.add(lblTitulo);
        panelCabecera.add(lblAyuda);

        JPanel panelFormulario = new JPanel(new MigLayout(
                "fillx,insets 0,hidemode 3,gapx 12,gapy 10",
                "[right,fill,150!][grow,fill,360:380:420]",
                "[][][][][]"));

        configurarCampo(txtUsuario, "Usuario");
        configurarCampo(txtEmail, "E-mail registrado");
        configurarCampo(txtDni, "DNI / CUIT / CUIL registrado");
        configurarCampo(txtNuevaContrasena, "Nueva contraseña");
        configurarCampo(txtRepetirContrasena, "Repetir nueva contraseña");

        txtNuevaContrasena.putClientProperty(FlatClientProperties.STYLE, "showRevealButton:true;showCapsLock:true");
        txtRepetirContrasena.putClientProperty(FlatClientProperties.STYLE, "showRevealButton:true;showCapsLock:true");

        if (usuarioInicial != null) {
            txtUsuario.setText(usuarioInicial.trim());
        }

        panelFormulario.add(new JLabel("Usuario"));
        panelFormulario.add(txtUsuario, "growx, h 34!, wrap");

        panelFormulario.add(new JLabel("E-mail"));
        panelFormulario.add(txtEmail, "growx, h 34!, wrap");

        panelFormulario.add(new JLabel("DNI / CUIT / CUIL"));
        panelFormulario.add(txtDni, "growx, h 34!, wrap");

        panelFormulario.add(new JLabel("Nueva contraseña"));
        panelFormulario.add(txtNuevaContrasena, "growx, h 34!, wrap");

        panelFormulario.add(new JLabel("Repetir contraseña"));
        panelFormulario.add(txtRepetirContrasena, "growx, h 34!, wrap");

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        JButton btnCancelar = new JButton("Cancelar");
        JButton btnGuardar = new JButton("Actualizar contraseña");
        btnGuardar.putClientProperty(FlatClientProperties.STYLE, "borderWidth:0;focusWidth:0");

        btnCancelar.addActionListener(e -> dispose());
        btnGuardar.addActionListener(e -> procesarRecuperacion());

        panelBotones.add(btnCancelar);
        panelBotones.add(btnGuardar);

        panelPrincipal.add(panelCabecera, BorderLayout.NORTH);
        panelPrincipal.add(panelFormulario, BorderLayout.CENTER);

        add(panelPrincipal, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        setMinimumSize(new Dimension(ANCHO_MINIMO, ALTO_MINIMO));
        pack();
        setSize(Math.max(getWidth(), ANCHO_MINIMO), Math.max(getHeight(), ALTO_MINIMO));
        setResizable(false);
        setLocationRelativeTo(getOwner());
        SwingUtilities.invokeLater(() -> txtUsuario.requestFocusInWindow());
    }

    private void configurarCampo(JTextField campo, String placeholder) {
        campo.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, placeholder);
        campo.setPreferredSize(new Dimension(380, 34));
    }

    private void procesarRecuperacion() {
        String usuario = txtUsuario.getText().trim();
        String email = txtEmail.getText().trim();
        String dni = txtDni.getText().trim();
        String nuevaContrasena = new String(txtNuevaContrasena.getPassword());
        String repetirContrasena = new String(txtRepetirContrasena.getPassword());

        if (usuario.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar el usuario.", "Validación", JOptionPane.WARNING_MESSAGE);
            txtUsuario.requestFocusInWindow();
            return;
        }
        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar el e-mail registrado.", "Validación", JOptionPane.WARNING_MESSAGE);
            txtEmail.requestFocusInWindow();
            return;
        }
        if (!validaciones.validarCorreoValido(email)) {
            JOptionPane.showMessageDialog(this, "El e-mail ingresado no tiene un formato válido.", "Validación", JOptionPane.WARNING_MESSAGE);
            txtEmail.requestFocusInWindow();
            return;
        }
        if (dni.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar el DNI, CUIT o CUIL registrado.", "Validación", JOptionPane.WARNING_MESSAGE);
            txtDni.requestFocusInWindow();
            return;
        }
        if (nuevaContrasena.isBlank()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar una nueva contraseña.", "Validación", JOptionPane.WARNING_MESSAGE);
            txtNuevaContrasena.requestFocusInWindow();
            return;
        }
        if (nuevaContrasena.length() < 4) {
            JOptionPane.showMessageDialog(this, "La nueva contraseña debe tener al menos 4 caracteres.", "Validación", JOptionPane.WARNING_MESSAGE);
            txtNuevaContrasena.requestFocusInWindow();
            return;
        }
        if (!nuevaContrasena.equals(repetirContrasena)) {
            JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden.", "Validación", JOptionPane.WARNING_MESSAGE);
            txtRepetirContrasena.requestFocusInWindow();
            return;
        }

        boolean actualizado = usuarioControlador.recuperarContrasena(usuario, email, dni, nuevaContrasena);
        if (actualizado) {
            JOptionPane.showMessageDialog(this,
                    "La contraseña fue actualizada correctamente. Ya puede ingresar al sistema.",
                    "Recuperación exitosa",
                    JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                    "No se encontró un usuario que coincida con el usuario, e-mail y DNI/CUIT/CUIL ingresados.",
                    "No fue posible recuperar la contraseña",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
