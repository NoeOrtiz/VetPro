package veterinaria.persistencia;

@Deprecated
public class TurnoDAO extends PeluqueriaDAO {
    // Clase puente por compatibilidad histórica.
}
