package veterinaria.persistencia;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import veterinaria.entidad.Producto;
import veterinaria.entidad.ProductoProveedor;
import veterinaria.entidad.Proveedor;

/**
 * DAO de ProductoProveedor (tabla puente Producto ↔ Proveedor).
 *
 * Importante: expone métodos que aceptan EntityManager para poder ejecutarse
 * dentro de transacciones ya abiertas (por ejemplo al crear/actualizar Producto
 * o al crear/actualizar una Orden de Compra).
 */
public class ProductoProveedorDAO {

    public EntityManager getEntityManager() {
        return JPAUtil.getEntityManager();
    }

    /**
     * Asegura que exista el vínculo Producto-Proveedor (activo=true por defecto).
     * Si ya existe, no hace nada.
     */
    public void asegurarVinculo(EntityManager em, Integer idProducto, Integer idProveedor) {
        if (em == null) throw new IllegalArgumentException("EntityManager null");
        if (idProducto == null || idProveedor == null) return;

        Long count = em.createQuery(
                "SELECT COUNT(pp) FROM ProductoProveedor pp "
                + "WHERE pp.producto.idProducto = :p AND pp.proveedor.idProveedor = :v",
                Long.class
        )
        .setParameter("p", idProducto)
        .setParameter("v", idProveedor)
        .getSingleResult();

        if (count != null && count > 0) {
            // si existe pero estaba inactivo, lo reactivamos
            em.createQuery(
                    "UPDATE ProductoProveedor pp SET pp.activo = true "
                    + "WHERE pp.producto.idProducto = :p AND pp.proveedor.idProveedor = :v"
            )
            .setParameter("p", idProducto)
            .setParameter("v", idProveedor)
            .executeUpdate();
            return;
        }

        Producto prodRef = em.getReference(Producto.class, idProducto);
        Proveedor provRef = em.getReference(Proveedor.class, idProveedor);

        ProductoProveedor pp = new ProductoProveedor();
        pp.setProducto(prodRef);
        pp.setProveedor(provRef);
        pp.setActivo(true);
        pp.setEsDefault(false);

        em.persist(pp);
    }

    /**
     * Sincroniza el proveedor "principal" del Producto (campo producto.proveedor) con la tabla puente:
     * - Asegura que exista el vínculo con ese proveedor.
     * - Deja ese vínculo como esDefault=true.
     * - Pone esDefault=false en los demás vínculos del mismo producto.
     */
    public void sincronizarProveedorDefault(EntityManager em, Producto producto) {
        if (em == null) throw new IllegalArgumentException("EntityManager null");
        if (producto == null || producto.getIdProducto() == null) return;

        Integer idProducto = producto.getIdProducto();
        Integer idProveedor = (producto.getProveedor() == null) ? null : producto.getProveedor().getIdProveedor();

        // Limpiar defaults anteriores
        em.createQuery("UPDATE ProductoProveedor pp SET pp.esDefault = false WHERE pp.producto.idProducto = :p")
                .setParameter("p", idProducto)
                .executeUpdate();

        if (idProveedor == null) {
            return;
        }

        // Asegurar vínculo
        asegurarVinculo(em, idProducto, idProveedor);

        // Set default en el vínculo actual
        em.createQuery(
                "UPDATE ProductoProveedor pp SET pp.esDefault = true, pp.activo = true "
                + "WHERE pp.producto.idProducto = :p AND pp.proveedor.idProveedor = :v"
        )
        .setParameter("p", idProducto)
        .setParameter("v", idProveedor)
        .executeUpdate();
    }

    /**
     * Lista los proveedores asociados a un producto (solo activos).
     */
    public List<ProductoProveedor> listarPorProducto(Integer idProducto) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<ProductoProveedor> q = em.createQuery(
                    "SELECT pp FROM ProductoProveedor pp "
                    + "LEFT JOIN FETCH pp.proveedor pr "
                    + "WHERE pp.producto.idProducto = :p AND (pp.activo IS NULL OR pp.activo = true) "
                    + "ORDER BY (CASE WHEN pp.esDefault = true THEN 0 ELSE 1 END), pr.razonSocial",
                    ProductoProveedor.class
            );
            q.setParameter("p", idProducto);
            return q.getResultList();
        } finally {
            if (em != null) em.close();
        }
    }
}
