
package veterinaria.persistencia;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;
import veterinaria.entidad.Cliente;
import veterinaria.entidad.Mascota;

public class MascotaDAO {
    public EntityManager getEntityManager() {
        return JPAUtil.getEntityManager();
    }

    public boolean crear(Mascota mascota) throws Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(mascota);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw e;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
    
    public Mascota buscarPorCliente(Cliente cliente) {
        EntityManager em = getEntityManager();
        try {
            // Traer también Cliente.Persona para evitar LazyInitializationException en la UI (Swing)
            // Nota: Cliente.persona está mapeado como LAZY.
            TypedQuery<Mascota> query = em.createQuery(
                    "SELECT m FROM Mascota m "
                    + "LEFT JOIN FETCH m.cliente c "
                    + "LEFT JOIN FETCH c.persona "
                    + "WHERE m.cliente = :cliente",
                    Mascota.class
            );
            query.setParameter("cliente", cliente);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;  
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
    
    public List<Mascota> buscarTodos() {
        EntityManager em = getEntityManager();
        try {
            // Traer Cliente.Persona para evitar LazyInitializationException cuando se muestran datos del dueño.
            TypedQuery<Mascota> query = em.createQuery(
                    "SELECT DISTINCT m FROM Mascota m "
                    + "LEFT JOIN FETCH m.cliente c "
                    + "LEFT JOIN FETCH c.persona",
                    Mascota.class
            );
            return query.getResultList();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
    
    public Mascota buscarPorId(Integer idMascota){
        EntityManager em = getEntityManager();
        try {
            // em.find() NO hace fetch de Cliente.Persona (Cliente.persona es LAZY),
            // por lo que luego explota en la UI al acceder a persona.getNombre().
            TypedQuery<Mascota> query = em.createQuery(
                    "SELECT m FROM Mascota m "
                    + "LEFT JOIN FETCH m.cliente c "
                    + "LEFT JOIN FETCH c.persona "
                    + "WHERE m.idMascota = :id",
                    Mascota.class
            );
            query.setParameter("id", idMascota);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            if (em != null) {
                em.close();
            }
        }        
    }
    
    public boolean actualizar(Mascota mascota) throws Exception {
        boolean retornar = false;
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(mascota);
            em.getTransaction().commit();
            retornar = true;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return retornar;
    }
    
    public boolean eliminar(Mascota mascota) throws Exception {
        EntityManager em = getEntityManager();
        boolean state = false;
        try {
            em.getTransaction().begin();
            Mascota mascotaManaged = em.find(Mascota.class, mascota.getIdMascota());
            if (mascotaManaged != null) {
                em.remove(mascotaManaged);
                state = true;
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw e;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return state;
    }
}
