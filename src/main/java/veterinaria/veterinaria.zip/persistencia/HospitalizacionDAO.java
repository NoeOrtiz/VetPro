
package veterinaria.persistencia;

import java.util.List;
import javax.persistence.EntityManager;
import veterinaria.entidad.Hospitalizacion;
import veterinaria.util.AppLog;
import veterinaria.util.enums.EstadoHospitalizacion;

public class HospitalizacionDAO {
    public EntityManager getEntityManager() {
        return JPAUtil.getEntityManager();
    }


    public Hospitalizacion buscarPorSlotId(EntityManager em, Long idSlot) {
        if (em == null || idSlot == null) return null;
        try {
            return em.createQuery(
                    "SELECT h FROM Hospitalizacion h WHERE h.slot IS NOT NULL AND h.slot.idSlot = :id",
                    Hospitalizacion.class
            ).setParameter("id", idSlot)
             .setMaxResults(1)
             .getResultStream()
             .findFirst()
             .orElse(null);
        } catch (Exception e) {
            AppLog.ignored(HospitalizacionDAO.class, "No se pudo buscar hospitalización por slot", e);
            return null;
        }
    }

    public Hospitalizacion buscarPorSlotId(Long idSlot) {
        EntityManager em = getEntityManager();
        try {
            return buscarPorSlotId(em, idSlot);
        } finally {
            em.close();
        }
    }

    public void crear(Hospitalizacion hospitalizacion) {
        EntityManager em = getEntityManager();
        em.getTransaction().begin();
        em.persist(hospitalizacion);
        em.getTransaction().commit();
        em.close();
    }

    public Hospitalizacion buscarPorId(Integer idHospitalizacion) {
        EntityManager em = getEntityManager();
        try {
            // Traemos relaciones usadas por formularios/vistas para evitar LazyInitializationException
            List<Hospitalizacion> res = em.createQuery(
                    "SELECT DISTINCT h FROM Hospitalizacion h "
                    + "LEFT JOIN FETCH h.veterinario v "
                    + "LEFT JOIN FETCH v.persona vp "
                    + "LEFT JOIN FETCH h.usuarioGestion ug "
                    + "LEFT JOIN FETCH ug.persona ugp "
                    + "LEFT JOIN FETCH h.cliente c "
                    + "LEFT JOIN FETCH c.persona cp "
                    + "LEFT JOIN FETCH h.mascota m "
                    + "LEFT JOIN FETCH m.cliente mc "
                    + "LEFT JOIN FETCH mc.persona mcp "
                    + "LEFT JOIN FETCH h.slot s "
                    + "WHERE h.idHospitalizacion = :id",
                    Hospitalizacion.class
            ).setParameter("id", idHospitalizacion)
             .getResultList();
            return (res == null || res.isEmpty()) ? null : res.get(0);
        } finally {
            em.close();
        }
    }

    public List<Hospitalizacion> obtenerTodas() {
        EntityManager em = getEntityManager();
        try {
            // En Swing no existe Open-Session-In-View: si la UI recorre relaciones LAZY
            // con el EntityManager cerrado, se dispara LazyInitializationException.
            // Por eso hacemos fetch join de las relaciones necesarias para pintar la tabla.
            return em.createQuery(
                    "SELECT DISTINCT h FROM Hospitalizacion h "
                    + "LEFT JOIN FETCH h.veterinario v "
                    + "LEFT JOIN FETCH v.persona vp "
                    + "LEFT JOIN FETCH h.usuarioGestion ug "
                    + "LEFT JOIN FETCH ug.persona ugp "
                    + "LEFT JOIN FETCH h.cliente c "
                    + "LEFT JOIN FETCH c.persona cp "
                    + "LEFT JOIN FETCH h.mascota m "
                    + "LEFT JOIN FETCH m.cliente mc "
                    + "LEFT JOIN FETCH mc.persona mcp "
                    + "LEFT JOIN FETCH h.slot s ",
                    Hospitalizacion.class
            ).getResultList();
        } finally {
            em.close();
        }
    }

    public void actualizar(Hospitalizacion hospitalizacion) {
        EntityManager em = getEntityManager();
        em.getTransaction().begin();
        em.merge(hospitalizacion);
        em.getTransaction().commit();
        em.close();
    }

    public void eliminar(Integer idHospitalizacion) {
        EntityManager em = getEntityManager();
        Hospitalizacion hospitalizacion = em.find(Hospitalizacion.class, idHospitalizacion);
        if (hospitalizacion != null) {
            em.getTransaction().begin();
            em.remove(hospitalizacion);
            em.getTransaction().commit();
        }
        em.close();
    }

    public boolean eliminar(Hospitalizacion hospitalizacion) throws Exception {
        EntityManager em = getEntityManager();
        boolean state = false;
        try {
            em.getTransaction().begin();
            Hospitalizacion hospitalizacionManaged = em.find(Hospitalizacion.class, hospitalizacion.getIdHospitalizacion());
            if (hospitalizacionManaged != null) {
                String estado = hospitalizacionManaged.getEstado();
                if (EstadoHospitalizacion.ALTA.getEtiqueta().equalsIgnoreCase(estado)) {
                    em.remove(hospitalizacionManaged);
                    em.getTransaction().commit();
                    state = true;
                } else {
                    em.getTransaction().rollback();

                }
            }
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw e;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return state;
    }


    /**
     * Devuelve la hospitalización ACTIVA (internación en curso) más reciente para una mascota.
     *
     * Regla de negocio (tabla hospitalizacion): se considera activa cuando el estado es
     * "Internado" (independiente de fechaAlta, por compatibilidad con datos históricos).
     *
     * Nota: antes se usaba "Dado de Alta" (estado de Procedimiento). En Hospitalización
     * el alta es "Alta medica" (ver {@link EstadoHospitalizacion}).
     */
    public Hospitalizacion obtenerActivaPorMascota(Integer idMascota) {
        EntityManager em = getEntityManager();
        try {
            List<Hospitalizacion> res = em.createQuery(
                    "SELECT h FROM Hospitalizacion h "
                    + "WHERE h.mascota.idMascota = :idMascota "
                    + "AND LOWER(COALESCE(h.estado, '')) = :estadoInternado "
                    + "ORDER BY h.fechaIngreso DESC, h.hora DESC, h.idHospitalizacion DESC",
                    Hospitalizacion.class
            )
            .setParameter("idMascota", idMascota)
            .setParameter("estadoInternado", EstadoHospitalizacion.INTERNADO.getEtiqueta().toLowerCase())
            .setMaxResults(1)
            .getResultList();

            return (res == null || res.isEmpty()) ? null : res.get(0);
        } finally {
            em.close();
        }
    }

    /**
     * Indica si existe alguna hospitalización en estado "Internado" para la mascota.
     * Permite excluir un registro (útil cuando se actualiza un registro existente).
     */
    public boolean existeInternadoPorMascota(Integer idMascota, Integer idExcluir) {
        EntityManager em = getEntityManager();
        try {
            Long c = em.createQuery(
                    "SELECT COUNT(h) FROM Hospitalizacion h "
                    + "WHERE h.mascota.idMascota = :idMascota "
                    + "AND LOWER(COALESCE(h.estado, '')) = :estadoInternado "
                    + "AND (:idExcluir IS NULL OR h.idHospitalizacion <> :idExcluir)",
                    Long.class
            )
                    .setParameter("idMascota", idMascota)
                    .setParameter("estadoInternado", EstadoHospitalizacion.INTERNADO.getEtiqueta().toLowerCase())
                    .setParameter("idExcluir", idExcluir)
                    .getSingleResult();

            return c != null && c.longValue() > 0L;
        } finally {
            em.close();
        }
    }

    public boolean existeInternadoPorMascota(Integer idMascota) {
        return existeInternadoPorMascota(idMascota, null);
    }

}
