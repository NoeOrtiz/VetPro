package veterinaria.persistencia;

import javax.persistence.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import veterinaria.entidad.Visita;
import veterinaria.servicio.AuditoriaService;

public class VisitaDAO {
    private final AuditoriaService auditoriaService = new AuditoriaService();

    public EntityManager getEntityManager() {
        return JPAUtil.getEntityManager();
    }

    public void crear(Visita visita) {
        EntityManager em = getEntityManager();
        em.getTransaction().begin();
        em.persist(visita);
        em.getTransaction().commit();
        auditoriaService.registrar("CREATE", "Visita", (visita!=null? Long.valueOf(visita.getIdVisita()): null), "VisitaDAO", "Alta de visita", AuditoriaService.RESULT_OK, null, null, null);
        em.close();
    }

    public Visita buscarPorId(Integer idVisita) {
        EntityManager em = getEntityManager();
        Visita visita = em.find(Visita.class, idVisita);
        em.close();
        return visita;
    }

    public List<Visita> obtenerTodas() {
        EntityManager em = getEntityManager();
        List<Visita> visitas = em.createQuery("SELECT v FROM Visita v", Visita.class).getResultList();
        em.close();
        return visitas;
    }

    public void actualizar(Visita visita) {
        EntityManager em = getEntityManager();
        em.getTransaction().begin();
        em.merge(visita);
        em.getTransaction().commit();
        
        auditoriaService.registrar("UPDATE", "Visita", (visita!=null? Long.valueOf(visita.getIdVisita()): null), "VisitaDAO", "Actualización de visita", AuditoriaService.RESULT_OK, null, null, null);
em.close();
    }

    public void eliminar(Integer idVisita) {
        EntityManager em = getEntityManager();
        Visita visita = em.find(Visita.class, idVisita);
        if (visita != null) {
            em.getTransaction().begin();
            em.remove(visita);
            em.getTransaction().commit();
        }
        em.close();
    }

    public boolean eliminar(Visita visita) throws Exception {
        EntityManager em = getEntityManager();
        boolean state = false;
        try {
            em.getTransaction().begin();
            Visita visitaManaged = em.find(Visita.class, visita.getIdVisita());
            if (visitaManaged != null) {
                // ⚠️ En este proyecto no se elimina físicamente una visita.
                // Se hace una baja lógica cambiando el estado a "CANCELADO".
                String estado = (visitaManaged.getEstado() != null) ? visitaManaged.getEstado().trim().toUpperCase() : "";
                if (!"FINALIZADO".equals(estado) && !"CANCELADO".equals(estado)) {
                    visitaManaged.setEstado("CANCELADO");
                    em.merge(visitaManaged);
                    em.getTransaction().commit();
                    
            auditoriaService.registrar("DELETE", "Visita", (visita!=null? Long.valueOf(visita.getIdVisita()): null), "VisitaDAO", "Baja de visita", AuditoriaService.RESULT_OK, null, null, null);
state = true;
                } else {
                    em.getTransaction().rollback();
                }
            }
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw e;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return state;
    }

    /**
     * Cancelación (baja lógica) de una visita.
     *
     * Regla: no permite cancelar si está FINALIZADO o ya CANCELADO.
     */
    public boolean cancelar(Visita visita) throws Exception {
        if (visita == null || visita.getIdVisita() == null) {
            return false;
        }
        EntityManager em = getEntityManager();
        boolean ok = false;
        try {
            em.getTransaction().begin();
            Visita managed = em.find(Visita.class, visita.getIdVisita());
            if (managed == null) {
                em.getTransaction().rollback();
                return false;
            }

            String estado = (managed.getEstado() != null) ? managed.getEstado().trim().toUpperCase() : "";
            if ("FINALIZADO".equals(estado) || "CANCELADO".equals(estado)) {
                em.getTransaction().rollback();
                return false;
            }

            managed.setEstado("CANCELADO");
            em.merge(managed);
            em.getTransaction().commit();
            
            auditoriaService.registrar("UPDATE", "Visita", (visita!=null? Long.valueOf(visita.getIdVisita()): null), "VisitaDAO", "Cancelación de visita", AuditoriaService.RESULT_OK, null, null, null);
ok = true;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw e;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return ok;
    }

}