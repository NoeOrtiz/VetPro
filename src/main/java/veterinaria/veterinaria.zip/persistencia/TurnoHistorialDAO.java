package veterinaria.persistencia;

@Deprecated
public class TurnoHistorialDAO extends PeluqueriaHistorialDAO {
    // Clase puente por compatibilidad histórica.
}
